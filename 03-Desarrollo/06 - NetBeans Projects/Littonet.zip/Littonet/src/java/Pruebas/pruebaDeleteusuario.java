/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.usuarioDAO;
import Modelo.usuario;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaDeleteusuario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here

        /*usuarioDAO usuarioDao = new usuarioDAO();
        usuario usuario = usuarioDao.consultausuario(0);

        if (usuario != null) {
            System.out.println("datos : " + usuario.getNombre() + " " + usuario.getApellido() + usuario.getDocumento() + usuario.getCelular() + usuario.getCorreo()
                    + usuario.getDireccion() + usuario.getUsername() + usuario.getContraseña() + usuario.getTipo_documento_idtipo_documento() + usuario.getCiudad_idciudad() + usuario.getPerfil_idperfil());

        } else {
            System.out.println("El usuario no existe :");
        }  */
        
       usuarioDAO usuarioDao = new usuarioDAO();
        ArrayList<usuario> listadousuarios;
        listadousuarios = usuarioDao.consultarlistausuario(' ', "", "", "", "", "", "", "", "", ' ', ' ', ' ');

        for (usuario U : listadousuarios) {

            System.out.println("id. :" + U.getIdusuario()+ " nombre ; " + U.getNombre()+ " apellido ; " + U.getApellido()+ " documento ; " + U.getDocumento()+ " celular ; " + U.getCelular()+ " correo ; " + U.getCorreo()+ " direccion ; " + U.getDireccion()+ " username ; " + U.getUsername()+ " clave ; " + U.getClave()+ " Tipo_documento_idtipo_documento ; " + U.getTipo_documento_idtipo_documento()+ " Perfil_idperfil ; " + U.getPerfil_idperfil()+ " Ciudad_idciudad ; " + U.getCiudad_idciudad());
        }
        usuarioDao.deleteusuario(listadousuarios.get(0));
        listadousuarios = usuarioDao.consultarlistausuario(' ', "", "", "", "", "", "", "", "", ' ', ' ', ' ');

        for (usuario U : listadousuarios) {

            System.out.println("id. :" + U.getIdusuario()+ " nombre ; " + U.getNombre()+ " apellido ; " + U.getApellido()+ " documento ; " + U.getDocumento()+ " celular ; " + U.getCelular()+ " correo ; " + U.getCorreo()+ " direccion ; " + U.getDireccion()+ " username ; " + U.getUsername()+ " clave ; " + U.getClave()+ " Tipo_documento_idtipo_documento ; " + U.getTipo_documento_idtipo_documento()+ " Perfil_idperfil ; " + U.getPerfil_idperfil()+ " Ciudad_idciudad ; " + U.getCiudad_idciudad());
        }

    }

}
