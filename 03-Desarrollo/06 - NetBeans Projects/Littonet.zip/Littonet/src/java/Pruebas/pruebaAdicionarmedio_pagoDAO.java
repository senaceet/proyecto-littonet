/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.medio_pagoDAO;
import Modelo.medio_pago;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author pacho
 */
public class pruebaAdicionarmedio_pagoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logich here
        medio_pagoDAO pagoDAO = new medio_pagoDAO();
        medio_pago pagos = new medio_pago();

        Scanner leer = new Scanner(System.in);

        String descripcion = "";

        System.out.println("Por favor escoger el medio de pago");
        descripcion = leer.nextLine();
        pagos.setDescripcion(descripcion);
        String respuesta = pagoDAO.adicionarpago(pagos);
        if (respuesta.length() == 0) {
            System.out.println("Forma de pago Registrado");
        } else {
            System.out.println("Ocurrio un error" + respuesta);
        }

    }
}
