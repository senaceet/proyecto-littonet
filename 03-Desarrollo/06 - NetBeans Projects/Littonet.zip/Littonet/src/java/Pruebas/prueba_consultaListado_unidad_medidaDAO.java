/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.unidad_medidaDAO;
import Modelo.unidad_medida;
import java.util.ArrayList;
/**
 *
 * @author David
 */
public class prueba_consultaListado_unidad_medidaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA LISTADO UNIDAD DE MEDIDA
        
        unidad_medidaDAO unidad_medida_dao = new unidad_medidaDAO();
        ArrayList<unidad_medida> mi_listado_unidad_medida_dao = new ArrayList<unidad_medida>();
        mi_listado_unidad_medida_dao = unidad_medida_dao.consultar_listado_unidad(' ', "");
        
        int size = mi_listado_unidad_medida_dao.size(); 
        
        System.out.println("  <table border = \"1\"> <br> <td> idunidad_medida </td> <td> descripcion </td>  "); 
        
        for (unidad_medida L : mi_listado_unidad_medida_dao) {
            System.out.println("  <tr>  ");
            
            System.out.println("  <td>  " + L.getIdunidad_medida() + "  </td>  ");
            System.out.println("  <td>  " + L.getDescripcion()+ "  </td>  ");
            
            System.out.println(" <tr> ");
        }
        System.out.println("  </table>  ");
    }
    
}
