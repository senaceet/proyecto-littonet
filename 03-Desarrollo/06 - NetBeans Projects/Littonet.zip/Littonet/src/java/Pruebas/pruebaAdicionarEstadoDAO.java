/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.estadoDAO;
import java.sql.SQLException;
import java.util.Scanner;
import Modelo.estado;

/**
 *
 * @author andre
 */
public class pruebaAdicionarEstadoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR PERFILES 
        
        estadoDAO estadoDao = new estadoDAO ();
        estado misEstados = new estado ();
        
        Scanner Leer = new Scanner (System.in);
        
        String Descripcion = "";
        
        System.out.println("Por favor digite un estado");
        Descripcion = Leer.next();
        misEstados.setDescripcion(Descripcion);
        String respuesta = estadoDao.adicionarestado (misEstados);
        if (respuesta.length()== 0){
            System.out.println("Estado Registrado");
        } else {
            System.out.println("Se presentó un error" + respuesta);
        }
      
        
        
    }
    
}
