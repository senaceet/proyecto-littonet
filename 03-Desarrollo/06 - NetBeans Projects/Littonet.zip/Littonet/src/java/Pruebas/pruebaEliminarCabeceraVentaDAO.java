/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.cabecera_ventaDAO;
import Modelo.cabecera_venta;
import java.util.ArrayList;

/**
 *
 * @author andre
 */
public class pruebaEliminarCabeceraVentaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA BORRAR REGISTROS
        
        cabecera_ventaDAO cabecera_ventaDao = new cabecera_ventaDAO();
        ArrayList<cabecera_venta>misListadosCabeceras_venta = cabecera_ventaDao.consultarListadoCabeceras_venta(' ', "", "", ' ', ' ', ' ');
        
        for (cabecera_venta C: misListadosCabeceras_venta) {
            
            System.out.println("Id." + C.getIdcabecera_venta() + "fecha" + C.getFecha() + "referencia" + 
                    C.getReferencia() + "usuario_idusuario" + C.getUsuario_idusuario() + "detalle_venta_iddetalle_venta" + 
                    C.getDetalle_venta_iddetalle_venta() + "tipo_documento2_idtipo_documento2" + C.getTipo_documento2_idtipo_documento2());
        }
        
        cabecera_ventaDao.eliminarCabecera_venta(misListadosCabeceras_venta.get(1));
        misListadosCabeceras_venta = cabecera_ventaDao.consultarListadoCabeceras_venta(' ',"", "", ' ', ' ', ' ');
        
        for (cabecera_venta C: misListadosCabeceras_venta) {
            
            System.out.println("Id." + C.getIdcabecera_venta() + "fecha" + C.getFecha() + "referencia" + 
                    C.getReferencia() + "usuario_idusuario" + C.getUsuario_idusuario() + "detalle_venta_iddetalle_venta" + 
                    C.getDetalle_venta_iddetalle_venta() + "tipo_documento2_idtipo_documento2" + C.getTipo_documento2_idtipo_documento2());
        }
        
    }
}
