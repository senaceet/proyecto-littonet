/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.categoriaDAO;
import Modelo.categoria;

/**
 *
 * @author David
 */
public class prueba_consultar_categoriaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        categoriaDAO categoria_dao = new categoriaDAO();
        categoria mi_categoria = categoria_dao.consultar_categoria(4);
        if (mi_categoria !=null){
            System.out.println(" Dato Encontrado: " + mi_categoria.getIdcategoria() + " - " + mi_categoria.getDescripcion() + " - " + mi_categoria.getSubcategoria_idsubcategoria());
        }
        else{
            System.out.println(" Dato no encontrado en Littonet ");
        }
    } 
}
