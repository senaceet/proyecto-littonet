/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.productoDAO;
import Modelo.producto;
import java.util.ArrayList;

/**
 *
 * @author David
 */
public class prueba_consultaListado_productoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA LISTADO UNIDAD DE MEDIDA
        
        productoDAO producto_dao = new productoDAO();
        ArrayList<producto> mi_listado_producto_dao = new ArrayList<producto>();
        mi_listado_producto_dao = producto_dao.consultar_listado_producto(' ',' ',"","",' ',' ');
        
        int size = mi_listado_producto_dao.size(); 
        
        System.out.println(" <table border = \"1\"> <br> <td> idproducto </td> <td> precio </td> <td> imagen </td> <td> caracteristicas </td> \n " +
                           " <td> unidad_medida_idunidad_medida </td> <td> categoria_idcategoria </td>  "); 
        
        for (producto L : mi_listado_producto_dao) {
            System.out.println("  <tr>  ");
            
            System.out.println("  <td>  " + L.getIdproducto()+ "  </td>  ");
            System.out.println("  <td>  " + L.getPrecio()+ "  </td>  ");
            System.out.println("  <td>  " + L.getImagen()+ "  </td>  ");
            System.out.println("  <td>  " + L.getCaracteristicas()+ "  </td>  ");
            System.out.println("  <td>  " + L.getUnidad_medida_idunidad_medida()+ "  </td>  ");
            System.out.println("  <td>  " + L.getCategoria_idcategoria()+ "  </td>  ");
            
            System.out.println(" <tr> ");
        }
        System.out.println("  </table>  ");
    }    
}
