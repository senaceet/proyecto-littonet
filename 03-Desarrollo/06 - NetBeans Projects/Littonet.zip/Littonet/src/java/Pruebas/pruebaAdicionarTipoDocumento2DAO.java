/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.tipo_documento2DAO;
import java.sql.SQLException;
import java.util.Scanner;
import Modelo.tipo_documento2;

/**
 *
 * @author andre
 */
public class pruebaAdicionarTipoDocumento2DAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR PERFILES 
        
        tipo_documento2DAO tipo_documento2Dao = new tipo_documento2DAO ();
        tipo_documento2 misTiposDocumento2 = new tipo_documento2 ();
        
        Scanner Leer = new Scanner (System.in);
        
        String Descripcion = "";
        
        System.out.println("Por favor digite los tipos de documento 2");
        Descripcion = Leer.next();
        misTiposDocumento2.setDescripcion(Descripcion);
        String respuesta = tipo_documento2Dao.adicionartipo_documento2 (misTiposDocumento2);
        if (respuesta.length()== 0){
            System.out.println("Tipo de Documento 2 Registrado");
        } else {
            System.out.println("Se presentó un error" + respuesta);
        }
      
        
        
    }
    
}
