/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.medio_pagoDAO;
import Modelo.medio_pago;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaConsultarListamedio_pago {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        medio_pagoDAO pagoDAO = new medio_pagoDAO();
        ArrayList<medio_pago> listadopagos = new ArrayList<medio_pago>();
        listadopagos = pagoDAO.consultarlistapago(' ', "");

        int size = listadopagos.size();
        System.out.println("<table border=\"1\"><br><td>idmedio_pago</td><td>descripcion</td>");

        for (medio_pago L : listadopagos) {
            System.out.println("<tr>");
            System.out.println("<td>" + L.getIdmedio_pago() + "</td>");
            System.out.println("<td>" + L.getDescripcion() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }

}
