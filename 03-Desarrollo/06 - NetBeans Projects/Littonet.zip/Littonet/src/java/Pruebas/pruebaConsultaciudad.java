/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.ciudadDAO;
import Modelo.ciudad;
import java.sql.SQLException;

/**
 *
 * @author pacho
 */
public class pruebaConsultaciudad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        ciudadDAO ciudadDao = new ciudadDAO();
        ciudad ciudades = ciudadDao.consultarciudad(1);

        if (ciudades != null) {
            System.out.println("Dato encontrado: " + ciudades.getIdciudad() + " - " + ciudades.getDescripcion());

        } else {
            System.out.println("Dato no encontrado");
        }
    }
}
