/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.especificacionDAO;
import Modelo.especificacion;

/**
 *
 * @author andre
 */
public class pruebaConsultarEspecificacionDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        especificacionDAO especificacionDao = new especificacionDAO ();
        especificacion misEspecificaciones = especificacionDao.consultarEspecificacion(1);
        
        if (misEspecificaciones != null) {
            System.out.println("El dato se encontró: " + misEspecificaciones.getIdespecificacion() + " - " + misEspecificaciones.getDescripcion());
        }else { 
            System.out.println("Dato no encontrado en la BD");
        }     
        
    }
    
}
