/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.subcategoriaDAO;
import Modelo.subcategoria;
import java.util.ArrayList;

/**
 *
 * @author David
 */
public class prueba_consultaListado_subcategoriaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA LISTADO UNIDAD DE MEDIDA
        
        subcategoriaDAO subcategoria_dao = new subcategoriaDAO();
        ArrayList<subcategoria> mi_listado_subcategoria_dao = new ArrayList<subcategoria>();
        mi_listado_subcategoria_dao = subcategoria_dao.consultar_listado_subcategoria(' ', "");
        
        int size = mi_listado_subcategoria_dao.size(); 
        
        System.out.println("  <table border = \"1\"> <br> <td> idsubcategoria </td> <td> descripcion </td>  "); 
        
        for (subcategoria L : mi_listado_subcategoria_dao) {
            System.out.println("  <tr>  ");
            
            System.out.println("  <td>  " + L.getIdsubcategoria()+ "  </td>  ");
            System.out.println("  <td>  " + L.getDescripcion()+ "  </td>  ");
            
            System.out.println(" <tr> ");
        }
        System.out.println("  </table>  ");
    }    
}
