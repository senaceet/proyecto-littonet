/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_documentoDAO;
import Modelo.tipo_documento;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author pacho
 */
public class pruebaAdicionartipo_documentoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        tipo_documentoDAO documentoDAO = new tipo_documentoDAO();
        tipo_documento documentos = new tipo_documento();

        Scanner leer = new Scanner(System.in);

        String descripcion = "";

        System.out.println("Por favor escoger el tipo de documento");
        descripcion = leer.nextLine();
        documentos.setDescripcion(descripcion);
        String respuesta = documentoDAO.adicionardocumento(documentos);
        if (respuesta.length() == 0) {
            System.out.println("Tipo de documento Registrado");
        } else {
            System.out.println("Ocurrio un error" + respuesta);
        }

    }
}
