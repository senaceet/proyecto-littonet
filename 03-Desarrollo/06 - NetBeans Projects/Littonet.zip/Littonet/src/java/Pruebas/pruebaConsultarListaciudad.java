/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.ciudadDAO;
import Modelo.ciudad;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaConsultarListaciudad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        ciudadDAO ciudadDao = new ciudadDAO();
        ArrayList<ciudad> listadociudad = new ArrayList<ciudad>();
        listadociudad = ciudadDao.consultarlistaciudad(' ', "");

        int size = listadociudad.size();
        System.out.println("<table border=\"1\"><br><td>idciudad</td><td>descripcion</td>");

        for (ciudad L : listadociudad) {
            System.out.println("<tr>");
            System.out.println("<td>" + L.getIdciudad() + "</td>");
            System.out.println("<td>" + L.getDescripcion() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }

}
