/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_documentoDAO;
import Modelo.tipo_documento;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author pacho
 */
public class pruebaActualizartipo_documento {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logich here
        tipo_documentoDAO documentoDAO = new tipo_documentoDAO();
        tipo_documento documentos = new tipo_documento();

        Scanner leer = new Scanner(System.in);

        String Descripcion;
        System.out.println("Por favor digita la nueva descripcion del tipo de documento");
        Descripcion = leer.nextLine();

        documentos.setDescripcion(Descripcion);
        documentos.setIdtipo_documento(1);

        String respuesta = documentoDAO.actualizardocumento(documentos);

        if (respuesta.length() == 0) {
            System.out.println("Tipo de documento actualizado");
        } else {
            System.out.println("Ocurrio un error" + respuesta);
        }

    }
}
