/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.detalle_ventaDAO;
import Modelo.detalle_venta;

/**
 *
 * @author andre
 */
public class pruebaConsultarDetalleVentaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        detalle_ventaDAO detalle_ventaDao = new detalle_ventaDAO ();
        detalle_venta misDetalles_venta = detalle_ventaDao.consultarDetalle_venta(1);
        
        if (misDetalles_venta != null) {
            System.out.println("El dato se encontró: " + misDetalles_venta.getIddetalle_venta() + " - " + misDetalles_venta.getCantidad()+ " - " + misDetalles_venta.getEstado_idestado()
                    + " - " + misDetalles_venta.getTipo_envio_idtipo_envio()+ " - " + misDetalles_venta.getMedio_pago_idmedio_pago()+ " - " + misDetalles_venta.getProducto_idproducto()+ " - " + misDetalles_venta.getEspecificacion_idespecificacion());
        } else {
            System.out.println("Dato no encontrado en la BD");
        }
        
    }
    
}