/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.perfilDAO;
import Modelo.perfil;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaDeleteperfil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here

        /*perfilDAO perfilesDao = new perfilDAO();   
         perfil perfiles =  perfilesDao.consultaperfil(0);

         if (perfiles != null) {
         System.out.println("datos : " + perfiles.getDescripcion() + " " + perfiles.getIdperfil());

         } else {
         System.out.println("El perfil no existe :");
         }*/
        perfilDAO perfilesDao = new perfilDAO();
        ArrayList<perfil> listadoperfiles = perfilesDao.consultarlistaperfil(' ', "");

        for (perfil P : listadoperfiles) {

            System.out.println("id. :" + P.getIdperfil() + " descripcion ; " + P.getDescripcion());
        }
        perfilesDao.deleteperfil(listadoperfiles.get(0));
        listadoperfiles = perfilesDao.consultarlistaperfil(' ', "");

        for (perfil P : listadoperfiles) {

            System.out.println("id. :" + P.getIdperfil() + " descripcion ; " + P.getDescripcion());
        }

    }

}
