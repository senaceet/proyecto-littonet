/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.categoriaDAO;
import Modelo.categoria;
import java.util.Scanner;

/**
 *
 * @author David
 */
public class prueba_actualizar_categoriaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        categoriaDAO categoria_dao = new categoriaDAO();
        categoria mi_categoria = new categoria ();
        
        Scanner Leer = new Scanner(System.in);
        
        String descripcion;
        System.out.println(" Ingrese la nueva descripción de la categoria ");
        descripcion = Leer.nextLine();
        
        mi_categoria.setDescripcion(descripcion);
        mi_categoria.setSubcategoria_idsubcategoria(1);
        mi_categoria.setIdcategoria(7);
        
        String respuesta = categoria_dao.actualizar_categoria(mi_categoria);
        
        if (respuesta.length() == 0) {
            System.out.println("  Información actualizada correctamente  ");
        } 
        else {
            System.out.println(" Error, No se ha podido actualizar: " + respuesta);
        }                        
    }
    
}
