/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.inventarioDAO;
import Modelo.inventario;
import java.util.ArrayList;

/**
 *
 * @author David
 */
public class prueba_borrar_inventarioDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        inventarioDAO inventario_dao = new inventarioDAO();
        ArrayList<inventario> mi_inventario = inventario_dao.consultar_listado_inventario(' ',"","",' ',' ');
        
        for (inventario X: mi_inventario){
            System.out.println ("\nID: " + X.getIdinventario()+ " Entrada: " + X.getEntrada()+ " Salida: " + X.getSalida()+ " Saldo: " + X.getSaldo()+ "\n " +
                                "Idproducto: "+ X.getProducto_idproducto());            
        }
        
        inventario_dao.borrar_inventario(mi_inventario.get(1));
        mi_inventario = inventario_dao.consultar_listado_inventario(' ',"","",' ',' ');
        
        for (inventario X: mi_inventario){
            System.out.println ("\nID: " + X.getIdinventario()+ " Entrada: " + X.getEntrada()+ " Salida: " + X.getSalida()+ " Saldo: " + X.getSaldo()+ "\n " +
                                "Idproducto: "+ X.getProducto_idproducto());            
        }    
    }
    
}
