/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;


import Controlador.perfilDAO;
import Modelo.perfil;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author pacho
 */
public class pruebaAdicionarperfilDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here

        perfilDAO perfilesDAO = new perfilDAO();
        perfil perfiles = new perfil();

        Scanner leer = new Scanner(System.in);

        String descripcion = "";

        System.out.println("Por favor escoger el tipo de perfil del usuario");
        descripcion = leer.nextLine();
        perfiles.setDescripcion(descripcion);

        String respuesta = perfilesDAO.adicionarperfil(perfiles);
        if (respuesta.length() == 0) {
            System.out.println("Perfil Registrado");
        } else {
            System.out.println("Ocurrio un error" + respuesta);
        }

    }
}
