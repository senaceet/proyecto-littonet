/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.unidad_medidaDAO;
import Modelo.unidad_medida;
import java.util.Scanner;

/**
 *
 * @author David
 */
public class prueba_actualizar_unidad_medidaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        unidad_medidaDAO unidad_medida_dao = new unidad_medidaDAO();
        unidad_medida mi_unidad_medida = new unidad_medida ();
        
        Scanner Leer = new Scanner(System.in);
        
        String descripcion;
        System.out.println(" Ingrese la nueva descripción de unidad de medida ");
        descripcion = Leer.nextLine();
        
        mi_unidad_medida.setDescripcion(descripcion);
        
        mi_unidad_medida.setIdunidad_medida(3);
        
        String respuesta = unidad_medida_dao.actualizar_unidad_medida(mi_unidad_medida);
        
        if (respuesta.length() == 0) {
            System.out.println("  Información actualizada correctamente  ");
        } 
        else {
            System.out.println(" Error, No se ha podido actualizar: " + respuesta);
        }                        
    }
    
}
