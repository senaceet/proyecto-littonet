/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.estadoDAO;
import Modelo.estado;

/**
 *
 * @author andre
 */
public class pruebaConsultarEstadosDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        estadoDAO estadoDao = new estadoDAO ();
        estado misEstados = estadoDao.consultarEstado(1);
        
        if (misEstados != null) {
            System.out.println("El dato se encontró: " + misEstados.getIdestado() + " - " + misEstados.getDescripcion());
        }else { 
            System.out.println("Dato no encontrado en la BD");
        }     
        
    }
    
}
