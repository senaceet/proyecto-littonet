/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.especificacionDAO;
import java.util.Scanner;
import Modelo.especificacion;

/**
 *
 * @author andre
 */
public class pruebaActualizarEspecificacionDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        especificacionDAO especificacionDao = new especificacionDAO ();
        especificacion misEspecificaciones = new especificacion();
        
        
            
        Scanner Leer = new Scanner(System.in);
            
        String Descripcion;
        System.out.println("Digite la nueva descripción");
        Descripcion = Leer.nextLine();
        
        misEspecificaciones.setDescripcion(Descripcion);
        
        misEspecificaciones.setIdespecificacion(2);
        
        String respuesta = especificacionDao.actualizarEspecificacion(misEspecificaciones);
                
        if (respuesta.length() == 0) {
            System.out.println("Especificacion Actualizada");
        } else {
            System.out.println("No se ha podido actualizar especificacion" + respuesta);
        }
        
        
        
    }
    
}
