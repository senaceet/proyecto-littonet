/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.estadoDAO;
import java.util.ArrayList;
import Modelo.estado;

/**
 *
 * @author andre
 */
public class pruebaConsultarListadosEstadoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA LISTADO PERFILES
        estadoDAO estadoDao = new estadoDAO ();
        ArrayList<estado>misListadosEstados = new ArrayList<estado>();
        misListadosEstados = estadoDao.consultarListadoEstados(' ', "");
        
        int size = misListadosEstados.size();
        
        System.out.println("<table border=\"1\"><br><td>idestado</td><td>descripcion</td>");
                
        for (estado L: misListadosEstados) {
            System.out.println("<tr>");
            System.out.println("<td>" + L.getIdestado() + "</td>");
            System.out.println("<td>" + L.getDescripcion() + "</td>");
            System.out.println("</tr>");
             
        }
        System.out.println("</table>"); 
    }
    
}

