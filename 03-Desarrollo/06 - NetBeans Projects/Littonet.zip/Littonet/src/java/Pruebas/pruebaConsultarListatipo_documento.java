/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_documentoDAO;
import Modelo.tipo_documento;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaConsultarListatipo_documento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        tipo_documentoDAO documentoDAO = new tipo_documentoDAO();
        ArrayList<tipo_documento> listadodocumentos = new ArrayList<tipo_documento>();
        listadodocumentos = documentoDAO.consultarlistadocumento(' ', "");

        int size = listadodocumentos.size();
        System.out.println("<table border=\"1\"><br><td>idtipo_documento</td><td>descripcion</td>");

        for (tipo_documento L : listadodocumentos) {
            System.out.println("<tr>");
            System.out.println("<td>" + L.getIdtipo_documento() + "</td>");
            System.out.println("<td>" + L.getDescripcion() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }

}
