/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_documentoDAO;
import Modelo.tipo_documento;
import java.sql.SQLException;

/**
 *
 * @author pacho
 */
public class pruebaConsultatipo_documento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        tipo_documentoDAO documentoDao = new tipo_documentoDAO();
        tipo_documento documento = documentoDao.consultardocumento(2);

        if (documento != null) {
            System.out.println("Dato encontrado: " + documento.getIdtipo_documento() + " - " + documento.getDescripcion());

        } else {
            System.out.println("Dato no encontrado");
        }
    }
}
