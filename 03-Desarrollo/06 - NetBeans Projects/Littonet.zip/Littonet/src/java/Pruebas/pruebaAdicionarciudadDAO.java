/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.ciudadDAO;
import Modelo.ciudad;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author pacho
 */
public class pruebaAdicionarciudadDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {

        ciudadDAO ciudadDao = new ciudadDAO();
        ciudad ciudades = new ciudad();

        Scanner leer = new Scanner(System.in);

        String descripcion = "";

        System.out.println("Por favor escoger la ciudad");
        descripcion = leer.nextLine();
        ciudades.setDescripcion(descripcion);
        String respuesta = ciudadDao.adicionarciudad(ciudades);
        if (respuesta.length() == 0) {
            System.out.println("Ciudad Registrada");
        } else {
            System.out.println("Ocurrio un error" + respuesta);
        }

    }
}
