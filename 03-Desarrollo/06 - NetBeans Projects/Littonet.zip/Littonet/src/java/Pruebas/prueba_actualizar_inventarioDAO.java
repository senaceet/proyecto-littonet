/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.inventarioDAO;
import Modelo.inventario;
import java.util.Scanner;

/**
 *
 * @author David
 */
public class prueba_actualizar_inventarioDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        inventarioDAO inventario_dao = new inventarioDAO();
        inventario mi_inventario = new inventario ();
        
        Scanner Leer = new Scanner(System.in);
        
        String entrada;
        System.out.println(" Ingrese la nueva entrada ");
        entrada = Leer.next();
        
        String salida;
        System.out.println(" Seleccone la nueva salida ");
        salida = Leer.next();
        
        int saldo;
        System.out.println(" Ingrese el nuevo saldo ");
        saldo = Leer.nextInt();
        
        mi_inventario.setEntrada(entrada);
        mi_inventario.setSalida(salida);
        mi_inventario.setSaldo(saldo);
        mi_inventario.setProducto_idproducto(2);
        
        mi_inventario.setIdinventario(2);
        
        String respuesta = inventario_dao.actualizar_producto(mi_inventario);
        
        if (respuesta.length() == 0) {
            System.out.println("  Información actualizada correctamente  ");
        } 
        else {
            System.out.println(" Error, No se ha podido actualizar: " + respuesta);
        }                        
    }
    
}
