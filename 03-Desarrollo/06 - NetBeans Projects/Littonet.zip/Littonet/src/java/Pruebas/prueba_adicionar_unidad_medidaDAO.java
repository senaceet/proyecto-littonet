/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.unidad_medidaDAO;
import Modelo.unidad_medida;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author David
 */
public class prueba_adicionar_unidad_medidaDAO {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR PERFILES
        unidad_medidaDAO unidad_medida_dao = new unidad_medidaDAO();
        unidad_medida unidades = new unidad_medida ();
            
            Scanner Leer = new Scanner(System.in);
            
            String Descripcion = "";
            
            System.out.println(" Digite la descripción de la unidad "); 
            Descripcion = Leer.next();
            unidades.setDescripcion(Descripcion);
            String respuesta = unidad_medida_dao.adicionar_unidad_medida(unidades); 
            if (respuesta.length()== 0) {
                System.out.println("  Información registrada correctamente  ");              
            }
            else {
                System.out.println(" Error en: " + respuesta );
            }                                
    } 
}
    

