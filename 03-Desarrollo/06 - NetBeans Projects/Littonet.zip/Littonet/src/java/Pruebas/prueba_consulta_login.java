/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.usuarioDAO;
import Modelo.usuario;
import java.sql.SQLException;

/**
 *
 * @author pacho
 */
public class prueba_consulta_login {

    /**
     * @param args the command line arguments
     */
 public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        usuarioDAO usuarioDao = new usuarioDAO();
        usuario usuario = usuarioDao.consulta_login("carlog");

        if (usuario != null) {
            System.out.println("Dato encontrado: " + usuario.getIdusuario() + " - " + usuario.getNombre() + " - " + usuario.getApellido() + " - " + usuario.getDocumento() + " - " + usuario.getCelular() + " - " + usuario.getCorreo() + " - " + usuario.getDireccion() + " - " + usuario.getUsername() + " - " + usuario.getClave() + " - " + usuario.getCiudad_idciudad()+ " - " + usuario.getPerfil_idperfil()+ " - " + usuario.getTipo_documento_idtipo_documento());
        } else {
            System.out.println("Dato no encontrado");
        }
    }
}
