/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.especificacionDAO;
import java.sql.SQLException;
import java.util.Scanner;
import Modelo.especificacion;

/**
 *
 * @author andre
 */
public class pruebaAdicionarEspecificacionDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR ESPECIFICACIONES
        
        especificacionDAO especificacionDao = new especificacionDAO ();
        especificacion misEspecificaciones = new especificacion ();
        
        Scanner Leer = new Scanner (System.in);
        
        String Descripcion = "";
        
        System.out.println("Por favor digite una especificación");
        Descripcion = Leer.next();
        misEspecificaciones.setDescripcion(Descripcion);
        String respuesta = especificacionDao.adicionarespecificacion (misEspecificaciones);
        if (respuesta.length()== 0){
            System.out.println("Tipo de Documento 2 Registrado");
        } else {
            System.out.println("Se presentó un error" + respuesta);
        }
      
        
        
    }
    
}

