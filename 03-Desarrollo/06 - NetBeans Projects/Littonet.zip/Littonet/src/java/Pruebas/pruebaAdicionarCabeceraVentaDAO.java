/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.cabecera_ventaDAO;
import java.sql.SQLException;
import java.util.Scanner;
import Modelo.cabecera_venta;

/**
 *
 * @author andre
 */
public class pruebaAdicionarCabeceraVentaDAO {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR PERFILES 
        
        cabecera_ventaDAO cabecera_ventaDao = new cabecera_ventaDAO ();
        cabecera_venta misCabecerasVenta = new cabecera_venta ();
        
        Scanner Leer = new Scanner (System.in);
        
        
        String fecha = "";
        int referencia = ' ';
        
        
        System.out.println("Por favor digite la fecha de la venta");
        fecha = Leer.next();
        Leer.nextLine ();
        
        System.out.println("Por favor digite el referencia de la venta");
        referencia = Leer.nextInt();
        Leer.nextLine ();
        
        misCabecerasVenta.setFecha(fecha);
        misCabecerasVenta.setReferencia(referencia);
        misCabecerasVenta.setUsuario_idusuario(1);
        misCabecerasVenta.setDetalle_venta_iddetalle_venta(1);
        misCabecerasVenta.setTipo_documento2_idtipo_documento2(1);
                      
        String respuesta = cabecera_ventaDao.adicionarcabecera_venta (misCabecerasVenta);
        if (respuesta.length()== 0){
            System.out.println("Cabecera Venta Registrada");
        } else {
            System.out.println("Se presentó un error" + respuesta);
        }
      
        
        
    }
    
}
