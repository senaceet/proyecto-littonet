/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_envioDAO;
import Modelo.tipo_envio;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author pacho
 */
public class pruebaAdicionartipo_envioDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR TIPO_ENVIO

        tipo_envioDAO envioDAO = new tipo_envioDAO();
        tipo_envio envios = new tipo_envio();

        Scanner leer = new Scanner(System.in);

        String descripcion = "";

        System.out.println("Por favor escoger el medio de envio");
        descripcion = leer.nextLine();
        envios.setDescripcion(descripcion);
        String respuesta = envioDAO.adicionarenvio(envios);
        if (respuesta.length() == 0) {
            System.out.println("Tipo de envio Registrado");
        } else {
            System.out.println("Ocurrio un error" + respuesta);
        }

    }
}
