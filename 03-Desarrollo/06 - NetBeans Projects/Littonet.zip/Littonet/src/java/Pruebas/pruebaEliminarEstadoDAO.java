/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.estadoDAO;
import java.util.ArrayList;
import Modelo.estado;

/**
 *
 * @author andre
 */
public class pruebaEliminarEstadoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA BORRAR REGISTROS

/*        
        estadoDAO estadoDao = new estadoDAO();
        estado miestado = estadoDao.consultarEstado(1);
        
        if (miestado != null) {
            
            System.out.println("datos :" + miestado.getDescripcion() + " " + miestado.getIdestado());
        
        } else {
            System.out.println("El perfil no existe :");
        }
*/
        
        estadoDAO estadoDao = new estadoDAO();
        ArrayList<estado>misListadosEstados = estadoDao.consultarListadoEstados(' ', "");
        
        for (estado E: misListadosEstados) {
            
            System.out.println("Id." + E.getIdestado() + "descripcion" + E.getDescripcion());
        }
        
        estadoDao.eliminarEstado (misListadosEstados.get(6));
        misListadosEstados = estadoDao.consultarListadoEstados(' ',"");
        
        for (estado E: misListadosEstados) {
            
            System.out.println("Id." + E.getIdestado() + "descripcion" + E.getDescripcion());
        }
        
    }
}