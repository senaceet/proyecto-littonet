/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.ciudadDAO;
import Modelo.ciudad;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaDeleteciudad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here

        /*      ciudadDAO ciudadDao = new ciudadDAO();
         ciudad ciudades = ciudadDao.consultarciudad(0);

         if (ciudades != null) {
         System.out.println("datos : " + ciudades.getDescripcion() + " " + ciudades.getIdciudad());

         } else {
         System.out.println("La ciudad no existe :");
         }*/
        
        ciudadDAO ciudadDao = new ciudadDAO();
        ArrayList<ciudad> listadociudad = ciudadDao.consultarlistaciudad(' ', "");

        for (ciudad C : listadociudad) {

            System.out.println("id. :" + C.getIdciudad() + " descripcion ; " + C.getDescripcion());
        }
        ciudadDao.deleteciudad(listadociudad.get(1));
        listadociudad = ciudadDao.consultarlistaciudad(' ', "");

        for (ciudad C : listadociudad) {

            System.out.println("id. :" + C.getIdciudad() + " descripcion ; " + C.getDescripcion());
        }

    }

}
