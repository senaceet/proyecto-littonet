/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.tipo_documento2DAO;
import java.util.ArrayList;
import Modelo.tipo_documento2;

/**
 *
 * @author andre
 */
public class pruebaConsultarListadosTipoDocumento2DAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA LISTADO TIPOS DOCUMENTO 2
        tipo_documento2DAO tipo_documento2Dao = new tipo_documento2DAO ();
        ArrayList<tipo_documento2>misListadosTipos_documento2 = new ArrayList<tipo_documento2>();
        misListadosTipos_documento2 = tipo_documento2Dao.consultarListadoTipos_documento2(' ', "");
        
        int size = misListadosTipos_documento2.size();
        
        System.out.println("<table border=\"1\"><br><td>idtipo_documento2</td><td>descripcion</td>");
                
        for (tipo_documento2 T: misListadosTipos_documento2) {
            System.out.println("<tr>");
            System.out.println("<td>" + T.getIdtipo_documento2() + "</td>");
            System.out.println("<td>" + T.getDescripcion() + "</td>");
            System.out.println("</tr>");
             
        }
        System.out.println("</table>"); 
    }
    
}
