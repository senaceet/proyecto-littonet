/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.tipo_documento2DAO;
import java.util.ArrayList;
import Modelo.tipo_documento2;

/**
 *
 * @author andre
 */
public class pruebaEliminarTipoDocumento2DAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA BORRAR REGISTROS

/*        
        tipo_documento2DAO tipo_documento2Dao = new tipo_documento2DAO();
        tipo_documento2 mitipo_documento2o = tipo_documento2Dao.consultarTipo_documento2(1);
        
        if (mitipo_documento2 != null) {
            
            System.out.println("datos :" + mitipo_documento2.getDescripcion() + " " + mitipo_documento2.getIdtipo_documento2());
        
        } else {
            System.out.println("El tipo de documento 2 no existe :");
        }
*/
        
        tipo_documento2DAO tipo_documento2Dao = new tipo_documento2DAO();
        ArrayList<tipo_documento2>misListadosTipos_documento2 = tipo_documento2Dao.consultarListadoTipos_documento2(' ', "");
        
        for (tipo_documento2 T: misListadosTipos_documento2) {
            
            System.out.println("Id." + T.getIdtipo_documento2() + "descripcion" + T.getDescripcion());
        }
        
        tipo_documento2Dao.eliminarTipo_documento2 (misListadosTipos_documento2.get(1));
        misListadosTipos_documento2 = tipo_documento2Dao.consultarListadoTipos_documento2(' ',"");
        
        for (tipo_documento2 T: misListadosTipos_documento2) {
            
            System.out.println("Id." + T.getIdtipo_documento2() + "descripcion" + T.getDescripcion());
        }
        
    }
}
