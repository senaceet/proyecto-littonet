/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.perfilDAO;
import Modelo.perfil;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaConsultarListaperfil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        perfilDAO perfilesDAO = new perfilDAO();
        ArrayList<perfil> listadoperfiles = new ArrayList<perfil>();
        listadoperfiles = perfilesDAO.consultarlistaperfil(' ', "");

        int size = listadoperfiles.size();
        System.out.println("<table border=\"1\"><br><td>idperfil</td><td>descripcion</td>");

        for (perfil L : listadoperfiles) {
            System.out.println("<tr>");
            System.out.println("<td>" + L.getIdperfil() + "</td>");
            System.out.println("<td>" + L.getDescripcion() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }

}
