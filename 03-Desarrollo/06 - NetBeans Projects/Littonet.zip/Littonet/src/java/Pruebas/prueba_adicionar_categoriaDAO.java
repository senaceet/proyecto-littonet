/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.categoriaDAO;
import Modelo.categoria;
import java.sql.SQLException;
import java.util.Scanner;
/**
 *
 * @author David
 */
public class prueba_adicionar_categoriaDAO {

    /** 
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR CATEGORIA 
        categoriaDAO categoria_dao = new categoriaDAO();
        categoria categorias = new categoria ();
          
            Scanner Leer = new Scanner(System.in);
            
            String descripcion = "";
             
            System.out.println(" Digite la descripción de la categoria "); 
            descripcion = Leer.next();
            Leer.nextLine();
            
            categorias.setDescripcion(descripcion);
            categorias.setSubcategoria_idsubcategoria(1);
            
            String respuesta = categoria_dao.adicionar_categoria(categorias);
            if (respuesta.length()== 0) {
                System.out.println("  Información registrada correctamente  ");               
            }
            else {
                System.out.println(" Error en: " + respuesta );
            }       
    }
}
    

