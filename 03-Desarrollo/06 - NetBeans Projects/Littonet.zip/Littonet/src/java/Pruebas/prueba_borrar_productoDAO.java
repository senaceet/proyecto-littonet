/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.productoDAO;
import Modelo.producto;
import java.util.ArrayList;

/**
 *
 * @author David
 */
public class prueba_borrar_productoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        productoDAO producto_dao = new productoDAO();
        ArrayList<producto> mi_producto = producto_dao.consultar_listado_producto(' ',' ',"","",' ',' ');
        
        for (producto X: mi_producto){
            System.out.println ("ID: " + X.getIdproducto()+ " Precio: " + X.getPrecio()+ " Imagen: " + X.getImagen()+ " Características: " + X.getCaracteristicas()+ "\n " +
                                "IdUnidad de medida: "+ X.getUnidad_medida_idunidad_medida() + " IdCategoria: " + X.getCategoria_idcategoria());            
        }
        
        producto_dao.borrar_producto(mi_producto.get(1));
        mi_producto = producto_dao.consultar_listado_producto(' ',' ',"","",' ',' ');
        
        for (producto X: mi_producto){
            System.out.println ("ID: " + X.getIdproducto()+ " Precio: " + X.getPrecio()+ " Imagen: " + X.getImagen()+ " Características: " + X.getCaracteristicas()+ "\n " +
                                "IdUnidad de medida: "+ X.getUnidad_medida_idunidad_medida() + " IdCategoria: " + X.getCategoria_idcategoria());            
        }    
    }  
}
