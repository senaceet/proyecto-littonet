/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.inventarioDAO;
import Modelo.inventario;
import java.util.ArrayList;

/**
 *
 * @author David
 */
public class prueba_consultaListado_inventarioDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA LISTADO UNIDAD DE MEDIDA
        
        inventarioDAO inventario_dao = new inventarioDAO();
        ArrayList<inventario> mi_listado_inventario_dao = new ArrayList<inventario>();
        mi_listado_inventario_dao = inventario_dao.consultar_listado_inventario(' ',"","",' ',' ');
        
        int size = mi_listado_inventario_dao.size(); 
        
        System.out.println(" \n <table border = \"1\"> <br> <td> idinventario </td> <td> entrada </td> <td> salida </td> <td> saldo </td> \n " +
                           " <td> producto_idproducto </td> "); 
        
        for (inventario L : mi_listado_inventario_dao) {
            System.out.println("  <tr>  ");
            
            System.out.println("  <td>  " + L.getIdinventario()+ "  </td>  ");
            System.out.println("  <td>  " + L.getEntrada()+ "  </td>  ");
            System.out.println("  <td>  " + L.getSalida()+ "  </td>  ");
            System.out.println("  <td>  " + L.getSaldo()+ "  </td>  ");
            System.out.println("  <td>  " + L.getProducto_idproducto()+ "  </td>  ");
            
            System.out.println(" <tr> ");
        }
        System.out.println("  </table>  ");
    }
    
}
