/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_envioDAO;
import Modelo.tipo_envio;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaDeletetipo_envio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here

        /*tipo_envioDAO envioDao = new tipo_envioDAO();
        tipo_envio envios = envioDao.consultarenvio(0);

        if (envios != null) {
            System.out.println("datos : " + envios.getDescripcion() + " " + envios.getIdtipo_envio());

        } else {
            System.out.println("El tipo de envio no existe :");
        }*/
        tipo_envioDAO envioDao = new tipo_envioDAO();
        ArrayList<tipo_envio> listadoenvios = envioDao.consultarlistaenvio(' ', "");

        for (tipo_envio E : listadoenvios) {

            System.out.println("id. :" + E.getIdtipo_envio() + " descripcion ; " + E.getDescripcion());
        }
        envioDao.deleteenvio(listadoenvios.get(0));
        listadoenvios = envioDao.consultarlistaenvio(' ', "");

        for (tipo_envio E : listadoenvios) {

            System.out.println("id. :" + E.getIdtipo_envio() + " descripcion ; " + E.getDescripcion());
        }

    }

}
