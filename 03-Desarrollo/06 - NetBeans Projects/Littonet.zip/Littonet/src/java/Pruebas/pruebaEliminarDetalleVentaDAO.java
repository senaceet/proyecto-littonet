/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.detalle_ventaDAO;
import Modelo.detalle_venta;
import java.util.ArrayList;

/**
 *
 * @author andre
 */
public class pruebaEliminarDetalleVentaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA BORRAR REGISTROS
        
        detalle_ventaDAO detalle_ventaDao = new detalle_ventaDAO();
        ArrayList<detalle_venta>misListadosDetalles_venta = detalle_ventaDao.consultarListadoDetalle_venta(' ', ' ', ' ', ' ', ' ', ' ', ' ');
        
        for (detalle_venta D: misListadosDetalles_venta) {
            
            System.out.println("Id." + D.getIddetalle_venta() + "cantidad" + D.getCantidad()+ "estado_idestado" + 
                    D.getEstado_idestado()+ "tipo_envio_idtipo_envio" + D.getTipo_envio_idtipo_envio()+ "medio_pago_idmedio_pago" + 
                    D.getMedio_pago_idmedio_pago()+ "producto_idproducto" + D.getProducto_idproducto()+ "especificacion_idespecificacion" + D.getEspecificacion_idespecificacion());
        }
        
        detalle_ventaDao.eliminarDetalle_venta(misListadosDetalles_venta.get(1));
        misListadosDetalles_venta = detalle_ventaDao.consultarListadoDetalle_venta(' ',' ', ' ', ' ', ' ', ' ', ' ');
        
        for (detalle_venta D: misListadosDetalles_venta) {
            
            System.out.println("Id." + D.getIddetalle_venta() + "cantidad" + D.getCantidad()+ "estado_idestado" + 
                    D.getEstado_idestado()+ "tipo_envio_idtipo_envio" + D.getTipo_envio_idtipo_envio()+ "medio_pago_idmedio_pago" + 
                    D.getMedio_pago_idmedio_pago()+ "producto_idproducto" + D.getProducto_idproducto()+ "especificacion_idespecificacion" + D.getEspecificacion_idespecificacion());
        }
        
    }
}

