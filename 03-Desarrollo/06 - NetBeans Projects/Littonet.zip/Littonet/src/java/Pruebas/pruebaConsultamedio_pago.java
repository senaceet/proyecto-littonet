/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.medio_pagoDAO;
import Modelo.medio_pago;
import java.sql.SQLException;

/**
 *
 * @author pacho
 */
public class pruebaConsultamedio_pago {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        medio_pagoDAO pagoDao = new medio_pagoDAO();
        medio_pago pagos = pagoDao.consultarpago(1);

        if (pagos != null) {
            System.out.println("Dato encontrado: " + pagos.getIdmedio_pago() + " - " + pagos.getDescripcion());

        } else {
            System.out.println("Dato no encontrado");
        }
    }
}

