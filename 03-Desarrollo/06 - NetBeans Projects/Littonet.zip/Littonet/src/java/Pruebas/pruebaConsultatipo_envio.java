/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_envioDAO;
import Modelo.tipo_envio;
import java.sql.SQLException;

/**
 *
 * @author pacho
 */
public class pruebaConsultatipo_envio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        tipo_envioDAO envioDao = new tipo_envioDAO();
        tipo_envio envios = envioDao.consultarenvio(1);

        if (envios != null) {
            System.out.println("Dato encontrado: " + envios.getIdtipo_envio() + " - " + envios.getDescripcion());

        } else {
            System.out.println("Dato no encontrado");
        }
    }
}
