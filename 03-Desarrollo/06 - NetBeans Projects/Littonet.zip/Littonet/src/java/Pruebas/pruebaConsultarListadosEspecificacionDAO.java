/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.especificacionDAO;
import java.util.ArrayList;
import Modelo.especificacion;

/**
 *
 * @author andre
 */
public class pruebaConsultarListadosEspecificacionDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA LISTADO PERFILES
        especificacionDAO especificacionDao = new especificacionDAO ();
        ArrayList<especificacion>misListadosEspecificaciones = new ArrayList<especificacion>();
        misListadosEspecificaciones = especificacionDao.consultarListadoEspecificacion(' ', "");
        
        int size = misListadosEspecificaciones.size();
        
        System.out.println("<table border=\"1\"><br><td>idespecificacion</td><td>descripcion</td>");
                
        for (especificacion E: misListadosEspecificaciones) {
            System.out.println("<tr>");
            System.out.println("<td>" + E.getIdespecificacion() + "</td>");
            System.out.println("<td>" + E.getDescripcion() + "</td>");
            System.out.println("</tr>");
             
        }
        System.out.println("</table>"); 
    }
    
}