/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.productoDAO;
import Modelo.producto;

/**
 *
 * @author David
 */
public class prueba_consultar_productoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        productoDAO producto_dao = new productoDAO();
        producto mi_producto = producto_dao.consultar_producto(2);
        if (mi_producto !=null){
            System.out.println(" Dato Encontrado: \n " + mi_producto.getIdproducto() + " - " + mi_producto.getPrecio() + " - " + mi_producto.getImagen() + " - " + 
                                mi_producto.getCaracteristicas() + " - " + mi_producto.getUnidad_medida_idunidad_medida() + " - " + mi_producto.getCategoria_idcategoria());
        }
        else{
            System.out.println(" Dato no encontrado en Littonet ");
        }
    }
    
}
