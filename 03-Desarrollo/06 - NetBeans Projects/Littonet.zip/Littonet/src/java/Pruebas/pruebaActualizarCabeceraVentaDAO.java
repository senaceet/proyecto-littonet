/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.cabecera_ventaDAO;
import Modelo.cabecera_venta;
import java.util.Scanner;

/**
 *
 * @author andre
 */
public class pruebaActualizarCabeceraVentaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        cabecera_ventaDAO cabecera_ventaDao = new cabecera_ventaDAO ();
        cabecera_venta misCabeceras_venta = new cabecera_venta();
        
        
            
        Scanner Leer = new Scanner(System.in);
            
        String fecha;
        System.out.println("Digite la nueva fecha");
        fecha = Leer.nextLine();
        
        int referencia;
        System.out.println("Digite la nueva referencia");
        referencia = Leer.nextInt();
        Leer.nextLine();
                
        misCabeceras_venta.setFecha(fecha);
        misCabeceras_venta.setReferencia(referencia);
        misCabeceras_venta.setUsuario_idusuario(2);
        misCabeceras_venta.setDetalle_venta_iddetalle_venta(2);
        misCabeceras_venta.setTipo_documento2_idtipo_documento2(1);
        
        misCabeceras_venta.setIdcabecera_venta(1);
        
        String respuesta = cabecera_ventaDao.actualizarCabecera_venta(misCabeceras_venta);
                
        if (respuesta.length() == 0) {
            System.out.println("Cabecera  de venta actualizada");
        } else {
            System.out.println("No se ha podido actualizar la cabecera de venta" + respuesta);
        }
        
        
        
    }
    
}