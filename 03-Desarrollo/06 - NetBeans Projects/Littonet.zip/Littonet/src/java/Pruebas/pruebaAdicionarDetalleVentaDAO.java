/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.detalle_ventaDAO;
import java.sql.SQLException;
import java.util.Scanner;
import Modelo.detalle_venta;

/**
 *
 * @author andre
 */
public class pruebaAdicionarDetalleVentaDAO {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR DETALLES DE VENTA 
        
        detalle_ventaDAO detalle_ventaDao = new detalle_ventaDAO ();
        detalle_venta misDetallesVenta = new detalle_venta ();
        
        Scanner Leer = new Scanner (System.in);
        
        
        int cantidad = ' ';        
        
        System.out.println("Por favor digite la cantidad");
        cantidad = Leer.nextInt();
        Leer.nextLine ();
        
        misDetallesVenta.setCantidad(cantidad);
        misDetallesVenta.setEstado_idestado(2);
        misDetallesVenta.setTipo_envio_idtipo_envio(1);
        misDetallesVenta.setMedio_pago_idmedio_pago(1);
        misDetallesVenta.setProducto_idproducto(3);
        misDetallesVenta.setEspecificacion_idespecificacion(1);
                      
        String respuesta = detalle_ventaDao.adicionardetalle_venta (misDetallesVenta);
        if (respuesta.length()== 0){
            System.out.println("Detalle de Venta Registrado");
        } else {
            System.out.println("Se presentó un error" + respuesta);
        }
      
        
        
    }
    
}
