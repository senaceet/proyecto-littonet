/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.tipo_documento2DAO;
import Modelo.tipo_documento2;

/**
 *
 * @author andre
 */
public class pruebaConsultarTiposDocumento2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        tipo_documento2DAO tipo_documento2Dao = new tipo_documento2DAO();
        tipo_documento2 misTipos_documento2 = tipo_documento2Dao.consultarTipo_documento2(2);

        if (misTipos_documento2 != null) {
            System.out.println("El dato se encontró: " + misTipos_documento2.getIdtipo_documento2() + " - " + misTipos_documento2.getDescripcion());
        } else {
            System.out.println("Dato no encontrado en la BD");
        }     
    
    }
    
}
