/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.subcategoriaDAO;
import Modelo.subcategoria;

/**
 *
 * @author David
 */
public class prueba_consultar_subcategoriaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        subcategoriaDAO subcategoria_dao = new subcategoriaDAO();
        subcategoria mi_subcategoria = subcategoria_dao.consultar_subcategoria(1);
        if (mi_subcategoria !=null){
            System.out.println(" Dato Encontrado: " + mi_subcategoria.getIdsubcategoria() + " - " + mi_subcategoria.getDescripcion());
        }
        else{
            System.out.println(" Dato no encontrado en Littonet ");
        }
    } 
}
