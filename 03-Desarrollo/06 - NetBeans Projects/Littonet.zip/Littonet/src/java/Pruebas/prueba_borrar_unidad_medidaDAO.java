/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.unidad_medidaDAO;
import Modelo.unidad_medida;
import java.util.ArrayList;

/**
 *
 * @author David
 */
public class prueba_borrar_unidad_medidaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        unidad_medidaDAO unidad_medida_dao = new unidad_medidaDAO();
        ArrayList<unidad_medida> mi_unidad_medida = unidad_medida_dao.consultar_listado_unidad(' ', "");
        
        for (unidad_medida X: mi_unidad_medida){
            System.out.println ("ID. : " + X.getIdunidad_medida() + " Descripcion: " + X.getDescripcion());            
        }
        
        unidad_medida_dao.borrar_unidad_medida(mi_unidad_medida.get(2));
        mi_unidad_medida = unidad_medida_dao.consultar_listado_unidad(' ', "");
        
        for (unidad_medida X: mi_unidad_medida){
            System.out.println ("ID. : " + X.getIdunidad_medida() + " Descripcion: " + X.getDescripcion());            
        }    
    }    
}
