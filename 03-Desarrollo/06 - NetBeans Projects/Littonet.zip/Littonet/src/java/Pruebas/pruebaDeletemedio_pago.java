/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.medio_pagoDAO;
import Modelo.medio_pago;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaDeletemedio_pago {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here

        /*medio_pagoDAO pagoDAO = new medio_pagoDAO();   
         medio_pago pagos = pagoDAO.consultarpago(0);

         if (pagos != null) {
         System.out.println("datos : " + pagos.getDescripcion() + " " + pagos.getIdmedio_pago());

         } else {
         System.out.println("El medio de pago no existe :");
         }*/
        
        medio_pagoDAO pagoDAO = new medio_pagoDAO();
        ArrayList<medio_pago> listadopagos = pagoDAO.consultarlistapago(' ', "");

        for (medio_pago M : listadopagos) {

            System.out.println("id. :" + M.getIdmedio_pago() + " descripcion ; " + M.getDescripcion());
        }
        pagoDAO.deletepago(listadopagos.get(0));
        listadopagos = pagoDAO.consultarlistapago(' ', "");

        for (medio_pago M : listadopagos) {

            System.out.println("id. :" + M.getIdmedio_pago() + " descripcion ; " + M.getDescripcion());
        }

    }

}
