/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.inventarioDAO;
import Modelo.inventario;

/**
 *
 * @author David
 */
public class prueba_consultar_inventarioDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        inventarioDAO inventario_dao = new inventarioDAO();
        inventario mi_inventario = inventario_dao.consultar_inventario(1);
        if (mi_inventario !=null){
            System.out.println(" Dato Encontrado: \n " + mi_inventario.getIdinventario() + " - " + mi_inventario.getEntrada() + " - " + mi_inventario.getSalida() +  
                               " - " +  mi_inventario.getSaldo() + " - " + mi_inventario.getProducto_idproducto());
        }
        else{
            System.out.println(" Dato no encontrado en Littonet ");
        }
    }    
}
