/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.categoriaDAO;
import Modelo.categoria;
import java.util.ArrayList;

/**
 *
 * @author David
 */
public class prueba_consultaListado_categoriaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA LISTADO UNIDAD DE MEDIDA
        
        categoriaDAO categoria_dao = new categoriaDAO();
        ArrayList<categoria> mi_listado_categoria_dao = new ArrayList<categoria>();
        mi_listado_categoria_dao = categoria_dao.consultar_listado_categoria(' ', "",' ');
        
        int size = mi_listado_categoria_dao.size(); 
        
        System.out.println("  <table border = \"1\"> <br> <td> idcategoria </td> <td> descripcion </td> <td> subcategoria_idsubcategoria </td> "); 
        
        for (categoria L : mi_listado_categoria_dao) {
            System.out.println("  <tr>  ");
            
            System.out.println("  <td>  " + L.getIdcategoria()+ "  </td>  ");
            System.out.println("  <td>  " + L.getDescripcion()+ "  </td>  ");
            System.out.println("  <td>  " + L.getSubcategoria_idsubcategoria()+ "  </td>  ");
            
            System.out.println(" <tr> ");
        }
        System.out.println("  </table>  ");
    }
    
}
