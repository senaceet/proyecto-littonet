/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.productoDAO;
import Modelo.producto;
import java.util.Scanner;

/**
 *
 * @author David
 */
public class prueba_actualizar_productoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        productoDAO producto_dao = new productoDAO();
        producto mi_producto = new producto ();
        
        Scanner Leer = new Scanner(System.in);
        
        int precio;
        System.out.println(" Ingrese el nuevo precio del producto ");
        precio = Leer.nextInt();
        
        String imagen;
        System.out.println(" Seleccone la imagen a cambiar ");
        imagen = Leer.next();
        
        String caracteristicas;
        System.out.println(" Ingrese las nuevas características ");
        caracteristicas = Leer.next();
        
        mi_producto.setPrecio(precio);
        mi_producto.setImagen(imagen);
        mi_producto.setCaracteristicas(caracteristicas);
        mi_producto.setUnidad_medida_idunidad_medida(1);
        mi_producto.setCategoria_idcategoria(7);
        
        mi_producto.setIdproducto(2);
        
        String respuesta = producto_dao.actualizar_producto(mi_producto);
        
        if (respuesta.length() == 0) {
            System.out.println("  Información actualizada correctamente  ");
        } 
        else {
            System.out.println(" Error, No se ha podido actualizar: " + respuesta);
        }                        
    }
    
}
