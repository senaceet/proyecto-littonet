/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_envioDAO;
import Modelo.tipo_envio;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author pacho
 */
public class pruebaActualizartipo_envio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logich here
        tipo_envioDAO envioDAO = new tipo_envioDAO();
        tipo_envio envios = new tipo_envio();

        Scanner leer = new Scanner(System.in);

        String Descripcion;
        System.out.println("Por favor digita la nueva descripcion de envio");
        Descripcion = leer.nextLine();

        envios.setDescripcion(Descripcion);
        envios.setIdtipo_envio(2);

        String respuesta = envioDAO.actualizarenvio(envios);

        if (respuesta.length() == 0) {
            System.out.println("envio actualizado");
        } else {
            System.out.println("Ocurrio un error" + respuesta);
        }

    }
}
