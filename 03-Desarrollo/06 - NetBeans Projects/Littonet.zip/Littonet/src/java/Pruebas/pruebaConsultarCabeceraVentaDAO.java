/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.cabecera_ventaDAO;
import Modelo.cabecera_venta;

/**
 *
 * @author andre
 */
public class pruebaConsultarCabeceraVentaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        cabecera_ventaDAO cabecera_ventaDao = new cabecera_ventaDAO ();
        cabecera_venta misCabeceras_venta = cabecera_ventaDao.consultarCabecera_venta(1);
        
        if (misCabeceras_venta != null) {
            System.out.println("El dato se encontró: " + misCabeceras_venta.getIdcabecera_venta() + " - " + misCabeceras_venta.getFecha() + " - " + misCabeceras_venta.getReferencia()
                    + " - " + misCabeceras_venta.getUsuario_idusuario() + " - " + misCabeceras_venta.getDetalle_venta_iddetalle_venta() + " - " + misCabeceras_venta.getTipo_documento2_idtipo_documento2());
        } else {
            System.out.println("Dato no encontrado en la BD");
        }
        
    }
    
}