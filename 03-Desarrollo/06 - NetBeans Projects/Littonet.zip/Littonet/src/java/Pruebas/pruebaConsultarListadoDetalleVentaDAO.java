/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.detalle_ventaDAO;
import Modelo.detalle_venta;
import java.util.ArrayList;

/**
 *
 * @author andre
 */
public class pruebaConsultarListadoDetalleVentaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA LISTADO DETALLES DE VENTA
        detalle_ventaDAO detalle_ventaDao = new detalle_ventaDAO ();
        ArrayList<detalle_venta>misListadosDetalles_venta = new ArrayList<detalle_venta>();
        misListadosDetalles_venta = detalle_ventaDao.consultarListadoDetalle_venta(' ', ' ', ' ', ' ', ' ', ' ', ' ');
        
        int size = misListadosDetalles_venta.size();
        
        System.out.println("<table border=\"1\"><br><td>idcabecera_venta</td> <td>cantidad</td> <td>estado_idestado</td> <td>tipo_envio_idtipo_envio</td> <td>medio_pago_idmedio_pago</td> "
                + "<td>producto_idproducto</td> <td>especificacion_idespecificacion</td>");
                
        for (detalle_venta D: misListadosDetalles_venta) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIddetalle_venta()+ "</td>");
            System.out.println("<td>" + D.getCantidad()+ "</td>");
            System.out.println("<td>" + D.getEstado_idestado()+ "</td>");
            System.out.println("<td>" + D.getTipo_envio_idtipo_envio()+ "</td>");
            System.out.println("<td>" + D.getMedio_pago_idmedio_pago()+ "</td>");
            System.out.println("<td>" + D.getProducto_idproducto()+ "</td>");
            System.out.println("<td>" + D.getEspecificacion_idespecificacion()+ "</td>");
            System.out.println("</tr>");
             
        }
        System.out.println("</table>"); 
    }
    
}