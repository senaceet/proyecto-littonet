/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.subcategoriaDAO;
import Modelo.subcategoria;
import java.util.Scanner;

/**
 *
 * @author David
 */
public class prueba_actualizar_subcategoriaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        subcategoriaDAO subcategoria_dao = new subcategoriaDAO();
        subcategoria mi_subcategoria = new subcategoria ();
        
        Scanner Leer = new Scanner(System.in);
        
        String descripcion;
        System.out.println(" Ingrese la nueva descripción de la subcategoria ");
        descripcion = Leer.nextLine();
        
        mi_subcategoria.setDescripcion(descripcion);
        
        mi_subcategoria.setIdsubcategoria(1);
        
        String respuesta = subcategoria_dao.actualizar_subcategoria(mi_subcategoria);
        
        if (respuesta.length() == 0) {
            System.out.println("  Información actualizada correctamente  ");
        } 
        else {
            System.out.println(" Error, No se ha podido actualizar: " + respuesta);
        }                        
    }
    
}
