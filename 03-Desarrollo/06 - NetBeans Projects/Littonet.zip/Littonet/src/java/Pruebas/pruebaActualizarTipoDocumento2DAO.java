/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_documento2DAO;
import java.util.Scanner;
import Modelo.tipo_documento2;

/**
 *
 * @author andre
 */
public class pruebaActualizarTipoDocumento2DAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        tipo_documento2DAO tipo_documento2Dao = new tipo_documento2DAO ();
        tipo_documento2 misTipos_documento2 = new tipo_documento2();
        
                  
        Scanner Leer = new Scanner(System.in);
            
        String Descripcion;
        System.out.println("Digite la nueva descripción");
        Descripcion = Leer.nextLine();
        
        misTipos_documento2.setDescripcion(Descripcion);
        
        misTipos_documento2.setIdtipo_documento2(1);
        
        String respuesta = tipo_documento2Dao.actualizarTipo_documento2(misTipos_documento2);
                
        if (respuesta.length() == 0) {
            System.out.println("Tipo de documento 2 Actualizado");
        } else {
            System.out.println("No se ha podido actualizar estado" + respuesta);
        }   
        
        
    }
    
}