/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.ciudadDAO;
import Modelo.ciudad;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author pacho
 */
public class pruebaActualizarciudad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here

        ciudadDAO ciudadDao = new ciudadDAO();
        ciudad ciudades = new ciudad();

        Scanner leer = new Scanner(System.in);

        String Descripcion;
        System.out.println("Por favor digita la nueva descripcion de ciudad");
        Descripcion = leer.nextLine();

        ciudades.setDescripcion(Descripcion);
        ciudades.setIdciudad(2);

        String respuesta = ciudadDao.actualizarciudad(ciudades);

        if (respuesta.length() == 0) {
            System.out.println("ciudad actualizada");
        } else {
            System.out.println("Ocurrio un error" + respuesta);
        }

    }
}
