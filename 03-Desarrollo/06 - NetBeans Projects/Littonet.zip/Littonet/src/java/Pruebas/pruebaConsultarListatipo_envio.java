/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_envioDAO;
import Modelo.tipo_envio;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaConsultarListatipo_envio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        tipo_envioDAO envioDAO = new tipo_envioDAO();
        ArrayList<tipo_envio> listadoenvios = new ArrayList<tipo_envio>();
        listadoenvios = envioDAO.consultarlistaenvio(' ', "");

        int size = listadoenvios.size();
        System.out.println("<table border=\"1\"><br><td>idtipo_envio</td><td>descripcion</td>");

        for (tipo_envio L : listadoenvios) {
            System.out.println("<tr>");
            System.out.println("<td>" + L.getIdtipo_envio() + "</td>");
            System.out.println("<td>" + L.getDescripcion() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }

}
