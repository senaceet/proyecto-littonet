/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.usuarioDAO;
import Modelo.usuario;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author pacho
 */
public class pruebaAdicionarusuarioDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here

        usuarioDAO usuariosDAO = new usuarioDAO();
        usuario usuarios = new usuario();

        Scanner leer = new Scanner(System.in);

        String nombre = "";
        String apellido = "";
        String documento = "";
        String celular = "";
        String correo = "";
        String direccion = "";
        String username = "";
        String clave = "";

        System.out.println("Por favor escribe tu nombre completo");
        nombre = leer.nextLine();

        System.out.println("Por favor escribe tu apellido completo");
        apellido = leer.nextLine();

        System.out.println("Por favor escribe tu numero de documento");
        documento = leer.nextLine();

        System.out.println("Por favor escribe tu numero de celular");
        celular = leer.nextLine();

        System.out.println("Por favor escribe tu correo electronico");
        correo = leer.nextLine();

        System.out.println("Por favor escribe tu direccion de residencia");
        direccion = leer.nextLine();

        System.out.println("Por favor escribe tu nombre de usuario");
        username = leer.nextLine();

        System.out.println("Por favor escribe tu contraseña");
        clave = leer.nextLine();

        usuarios.setNombre(nombre);
        usuarios.setApellido(apellido);
        usuarios.setDocumento(documento);
        usuarios.setCelular(celular);
        usuarios.setCorreo(correo);
        usuarios.setDireccion(direccion);
        usuarios.setUsername(username);
        usuarios.setClave(clave);
        usuarios.setCiudad_idciudad(1);
        usuarios.setPerfil_idperfil(1);
        usuarios.setTipo_documento_idtipo_documento(1);

        String respuesta = usuariosDAO.adicionarusuario(usuarios);
        if (respuesta.length() == 0) {
            System.out.println("Usuario Registrado");
        } else {
            System.out.println("Ocurrio un error" + respuesta);
        }

    }
}
