/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.productoDAO;
import Modelo.producto;
import java.sql.SQLException;
import java.util.Scanner;
/**
 *
 * @author David
 */
public class prueba_adicionar_productoDAO {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR CATEGORIA 
        productoDAO producto_dao = new productoDAO();
        producto productos = new producto ();
          
            Scanner Leer = new Scanner(System.in);
            
            int precio = 0;
            String imagen = "";
            String caracteristicas = "";
            
             
            System.out.println(" Digite el precio "); 
            precio = Leer.nextInt();
            Leer.nextLine();
            
            System.out.println(" Inserte una imágen "); 
            imagen = Leer.next();
            Leer.nextLine();
            
            System.out.println(" Ingrese una característica "); 
            caracteristicas = Leer.next();
            Leer.nextLine();
            
            productos.setPrecio(precio);
            productos.setImagen(imagen);
            productos.setCaracteristicas(caracteristicas);
            productos.setUnidad_medida_idunidad_medida(1);
            productos.setCategoria_idcategoria(7);
            
            String respuesta = producto_dao.adicionar_producto(productos);
            if (respuesta.length()== 0) {
                System.out.println("  Información registrada correctamente  ");               
            }
            else {
                System.out.println(" Error en: " + respuesta );
            }       
    }
    
}
