/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.detalle_ventaDAO;
import Modelo.detalle_venta;
import java.util.Scanner;

/**
 *
 * @author andre
 */
public class pruebaActualizarDetalleVentaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        detalle_ventaDAO detalle_ventaDao = new detalle_ventaDAO ();
        detalle_venta misDetalles_venta = new detalle_venta();
        
        
            
        Scanner Leer = new Scanner(System.in);
            
        int cantidad;
        System.out.println("Digite la nueva cantidad");
        cantidad = Leer.nextInt();
        Leer.nextLine();
                
        misDetalles_venta.setCantidad(cantidad);
        misDetalles_venta.setEstado_idestado(2);
        misDetalles_venta.setTipo_envio_idtipo_envio(1);
        misDetalles_venta.setMedio_pago_idmedio_pago(1);
        misDetalles_venta.setProducto_idproducto(2);
        misDetalles_venta.setEspecificacion_idespecificacion(1);

        misDetalles_venta.setIddetalle_venta(1);
        
        String respuesta = detalle_ventaDao.actualizarDetalle_venta(misDetalles_venta);
                
        if (respuesta.length() == 0) {
            System.out.println("Detalle de venta actualizada");
        } else {
            System.out.println("No se ha podido actualizar el detalle de venta" + respuesta);
        }
        
        
        
    }
    
}