/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.inventarioDAO;
import Modelo.inventario;
import java.sql.SQLException;
import java.util.Scanner;   
/**
 *
 * @author David
 */
public class prueba_adicionar_inventarioDAO {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR CATEGORIA 
        inventarioDAO inventario_dao = new inventarioDAO();
        inventario inventarios = new inventario ();
          
            Scanner Leer = new Scanner(System.in);
            
            String entrada = "";
            String salida = "";
            int saldo = 0;
            
             
            System.out.println(" Digite la entrada "); 
            entrada = Leer.next();
            Leer.nextLine();
            
            System.out.println(" Inserte la salida "); 
            salida = Leer.next();
            Leer.nextLine();
            
            System.out.println(" Ingrese el saldo "); 
            saldo = Leer.nextInt();
            Leer.nextLine();
            
            inventarios.setEntrada(entrada);
            inventarios.setSalida(salida);
            inventarios.setSaldo(saldo);
            inventarios.setProducto_idproducto(2);
                        
            String respuesta = inventario_dao.adicionar_inventario(inventarios);
            if (respuesta.length()== 0) {
                System.out.println("  Información registrada correctamente  ");               
            }
            else {
                System.out.println(" Error en: " + respuesta );
            }       
    }
    
}
