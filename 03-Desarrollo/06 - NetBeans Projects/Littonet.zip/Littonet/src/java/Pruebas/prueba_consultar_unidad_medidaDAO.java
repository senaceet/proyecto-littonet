/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.unidad_medidaDAO;
import Modelo.unidad_medida;
/**
 *
 * @author David
 */
public class prueba_consultar_unidad_medidaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        unidad_medidaDAO unidad_medida_dao = new unidad_medidaDAO();
        unidad_medida mi_unidad_medida = unidad_medida_dao.consultar_unidad_medida(1);
        if (mi_unidad_medida !=null){
            System.out.println(" Dato Encontrado: " + mi_unidad_medida.getIdunidad_medida() + " - " + mi_unidad_medida.getDescripcion());
        }
        else{
            System.out.println(" Dato no encontrado en Littonet ");
        }
    }
    
}
