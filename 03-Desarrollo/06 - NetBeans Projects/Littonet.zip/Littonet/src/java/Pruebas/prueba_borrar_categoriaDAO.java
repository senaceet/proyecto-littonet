/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.categoriaDAO;
import Modelo.categoria;
import java.util.ArrayList;

/**
 *
 * @author David
 */
public class prueba_borrar_categoriaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        categoriaDAO categoria_dao = new categoriaDAO();
        ArrayList<categoria> mi_categoria = categoria_dao.consultar_listado_categoria(' ', "",' ');
        
        for (categoria X: mi_categoria){
            System.out.println ("ID: " + X.getIdcategoria() + " Descripcion: " + X.getDescripcion() + " IdSubcategoria: " + X.getSubcategoria_idsubcategoria());            
        }
        
        categoria_dao.borrar_categoria(mi_categoria.get(1));
        mi_categoria = categoria_dao.consultar_listado_categoria(' ', "",' ');
        
        for (categoria X: mi_categoria){
            System.out.println ("ID: " + X.getIdcategoria() + " Descripcion: " + X.getDescripcion() + " IdSubcategoria: " + X.getSubcategoria_idsubcategoria());            
        }    
    }    
}
