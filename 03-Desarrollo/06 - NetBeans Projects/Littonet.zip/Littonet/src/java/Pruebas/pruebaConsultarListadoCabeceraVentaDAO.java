/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.cabecera_ventaDAO;
import Modelo.cabecera_venta;
import java.util.ArrayList;

/**
 *
 * @author andre
 */
public class pruebaConsultarListadoCabeceraVentaDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA LISTADO PERFILES
        cabecera_ventaDAO cabecera_ventaDao = new cabecera_ventaDAO ();
        ArrayList<cabecera_venta>misListadosCabeceras_venta = new ArrayList<cabecera_venta>();
        misListadosCabeceras_venta = cabecera_ventaDao.consultarListadoCabeceras_venta(' ', "", "", ' ', ' ', ' ');
        
        int size = misListadosCabeceras_venta.size();
        
        System.out.println("<table border=\"1\"><br><td>idcabecera_venta</td> <td>fecha</td> <td>referencia</td> <td>usuario_idusuario</td> "
                + "<td>detalle_venta_iddetalle_venta</td> <td>tipo_documento2_idtipo_documento2</td>");
                
        for (cabecera_venta L: misListadosCabeceras_venta) {
            System.out.println("<tr>");
            System.out.println("<td>" + L.getIdcabecera_venta() + "</td>");
            System.out.println("<td>" + L.getFecha()+ "</td>");
            System.out.println("<td>" + L.getReferencia()+ "</td>");
            System.out.println("<td>" + L.getUsuario_idusuario()+ "</td>");
            System.out.println("<td>" + L.getDetalle_venta_iddetalle_venta()+ "</td>");
            System.out.println("<td>" + L.getTipo_documento2_idtipo_documento2()+ "</td>");
            System.out.println("</tr>");
             
        }
        System.out.println("</table>"); 
    }
    
}