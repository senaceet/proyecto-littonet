/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.usuarioDAO;
import Modelo.usuario;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaConsultarListausuario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        usuarioDAO usuarioDAO = new usuarioDAO();
        ArrayList<usuario> listadousuarios = new ArrayList<usuario>();
        listadousuarios = usuarioDAO.consultarlistausuario(' ', "", "", "", "", "", "", "", "", ' ', ' ', ' ');

        int size = listadousuarios.size();
        System.out.println("<table border=\"1\"><br><td>idusuario</td><td>nombre</td><td>apellido</td><td>documento</td><td>celular</td><td>correo</td>"
                + "<td>direccion</td><td>username</td><td>clave</td><td>tipo_documento_idtipo_documento</td><td>ciudad_idciudad</td><td>perfil_idperfil</td>");

        for (usuario L : listadousuarios) {
            System.out.println("<tr>");
            System.out.println("<td>" + L.getIdusuario() + "</td>");
            System.out.println("<td>" + L.getNombre() + "</td>");
            System.out.println("<td>" + L.getApellido() + "</td>");
            System.out.println("<td>" + L.getDocumento() + "</td>");
            System.out.println("<td>" + L.getCelular() + "</td>");
            System.out.println("<td>" + L.getCorreo() + "</td>");
            System.out.println("<td>" + L.getDireccion() + "</td>");
            System.out.println("<td>" + L.getUsername() + "</td>");
            System.out.println("<td>" + L.getClave() + "</td>");
            System.out.println("<td>" + L.getTipo_documento_idtipo_documento() + "</td>");
            System.out.println("<td>" + L.getCiudad_idciudad() + "</td>");
            System.out.println("<td>" + L.getPerfil_idperfil() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }

}

