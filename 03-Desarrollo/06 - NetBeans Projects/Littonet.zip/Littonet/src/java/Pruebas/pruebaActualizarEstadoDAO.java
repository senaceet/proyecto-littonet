/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.estadoDAO;
import java.util.Scanner;
import Modelo.estado;

/**
 *
 * @author andre
 */
public class pruebaActualizarEstadoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        estadoDAO estadoDao = new estadoDAO ();
        estado misEstados = new estado();
        
        
            
        Scanner Leer = new Scanner(System.in);
            
        String Descripcion;
        System.out.println("Digite la nueva descripción");
        Descripcion = Leer.nextLine();
        
        misEstados.setDescripcion(Descripcion);
        
        misEstados.setIdestado(2);
        
        String respuesta = estadoDao.actualizarEstado(misEstados);
                
        if (respuesta.length() == 0) {
            System.out.println("Estado Actualizado");
        } else {
            System.out.println("No se ha podido actualizar estado" + respuesta);
        }
        
        
        
    }
    
}
