/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.tipo_documentoDAO;
import Modelo.tipo_documento;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class pruebaDeletetipo_documento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here

        /*tipo_documentoDAO documentoDao = new tipo_documentoDAO();
         tipo_documento documento = documentoDao.consultardocumento(0);

         if (documento != null) {
         System.out.println("datos : " + documento.getDescripcion() + " " + documento.getIdtipo_documento());

         } else {
         System.out.println("El tipo de documento no existe :");
         }*/
        
        tipo_documentoDAO documentoDao = new tipo_documentoDAO();
        ArrayList<tipo_documento> listadodocumentos = documentoDao.consultarlistadocumento(' ', "");

        for (tipo_documento D : listadodocumentos) {

            System.out.println("id. :" + D.getIdtipo_documento() + " descripcion ; " + D.getDescripcion());
        }
        documentoDao.deletedocumento(listadodocumentos.get(0));
        listadodocumentos = documentoDao.consultarlistadocumento(' ', "");

        for (tipo_documento D : listadodocumentos) {

            System.out.println("id. :" + D.getIdtipo_documento() + " descripcion ; " + D.getDescripcion());
        }

    }

}
