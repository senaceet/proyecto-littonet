/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.subcategoriaDAO;
import Modelo.subcategoria;
import java.sql.SQLException;
import java.util.Scanner;
/**
 *
 * @author David
 */
public class prueba_adicionar_subcategoriaDAO {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        // PRUEBA ADICIONAR SUBCATEGORIA
        subcategoriaDAO subcategorias_dao = new subcategoriaDAO();
        subcategoria subcategorias = new subcategoria ();
            
            Scanner Leer = new Scanner(System.in);
            String Descripcion = " ";
            System.out.println(" Digite la descripción de la subcategoria: "); 
            Descripcion = Leer.next();
            subcategorias.setDescripcion(Descripcion);
            String respuesta = subcategorias_dao.adicionar_subcategoria(subcategorias); 
            if (respuesta.length()== 0) {
                System.out.println("  Información registrada correctamente  ");              
            }
            else {
                System.out.println(" Error en: " + respuesta );
            }                                
    }
    
}
