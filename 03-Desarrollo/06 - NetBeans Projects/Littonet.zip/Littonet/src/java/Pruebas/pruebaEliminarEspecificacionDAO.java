/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import Controlador.especificacionDAO;
import java.util.ArrayList;
import Modelo.especificacion;

/**
 *
 * @author andre
 */
public class pruebaEliminarEspecificacionDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // PRUEBA BORRAR REGISTROS

/*        
        especificacionDAO especificacionDao = new especificacionDAO();
        especificacion miespecificacion = especificacionDao.consultarEspecificacion(1);
        
        if (miespecificacion != null) {
            
            System.out.println("datos :" + miespecificacion.getDescripcion() + " " + miespecificacion.getIdespecificacion());
        
        } else {
            System.out.println("La especificacion no existe :");
        }
*/
        
        especificacionDAO especificacionDao = new especificacionDAO();
        ArrayList<especificacion>misListadosEspecificaciones = especificacionDao.consultarListadoEspecificacion(' ', "");
        
        for (especificacion E: misListadosEspecificaciones) {
            
            System.out.println("Id." + E.getIdespecificacion() + "descripcion" + E.getDescripcion());
        }
        
        especificacionDao.eliminarEspecificacion (misListadosEspecificaciones.get(3));
        misListadosEspecificaciones = especificacionDao.consultarListadoEspecificacion(' ',"");
        
        for (especificacion E: misListadosEspecificaciones) {
            
            System.out.println("Id." + E.getIdespecificacion() + "descripcion" + E.getDescripcion());
        }
        
    }
}