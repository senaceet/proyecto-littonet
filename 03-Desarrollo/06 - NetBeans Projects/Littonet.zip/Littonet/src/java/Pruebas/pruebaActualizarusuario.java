/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pruebas;

import Controlador.usuarioDAO;
import Modelo.usuario;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author pacho
 */
public class pruebaActualizarusuario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        usuarioDAO usuarioDAO = new usuarioDAO();
        usuario usuarios = new usuario();

        Scanner Leer = new Scanner(System.in);

        String nombre;
        System.out.println("Por favor digita el nuevo nombre del usuario");
        nombre = Leer.nextLine();

        String apellido;
        System.out.println("Por favor digita el nuevo apellido del usuario");
        apellido = Leer.nextLine();

        String documento;
        System.out.println("Por favor digita el nuevo documento del usuario");
        documento = Leer.nextLine();

        String celular;
        System.out.println("Por favor digita el nuevo numero de celular del usuario");
        celular = Leer.nextLine();

        String correo;
        System.out.println("Por favor digita el nuevo correo del usuario");
        correo = Leer.nextLine();

        String direccion;
        System.out.println("Por favor digita la nueva direccion del usuario");
        direccion = Leer.nextLine();

        String username;
        System.out.println("Por favor digita el nuevo nombre de usuario");
        username = Leer.nextLine();

        String clave;
        System.out.println("Por favor digita la nueva contraseña del usuario");
        clave = Leer.nextLine();

        usuarios.setNombre(nombre);
        usuarios.setApellido(apellido);
        usuarios.setDocumento(documento);
        usuarios.setCelular(celular);
        usuarios.setCorreo(correo);
        usuarios.setDireccion(direccion);
        usuarios.setUsername(username);
        usuarios.setClave(clave);
        usuarios.setCiudad_idciudad(1);
        usuarios.setPerfil_idperfil(1);
        usuarios.setTipo_documento_idtipo_documento(1);
        usuarios.setIdusuario(1);

        String respuesta = usuarioDAO.actualizarusuario(usuarios);

        if (respuesta.length() == 0) {
            System.out.println("Usuario actualizado");
        } else {
            System.out.println("Ocurrio un error" + respuesta);
        }

    }
}
