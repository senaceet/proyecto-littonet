/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import Modelo.especificacion;

/**
 *
 * @author andre
 */
public class especificacionDAO {
    
   //METODO ADICIONAR UNA ESPECIFICACION
    
    public String adicionarespecificacion(especificacion OBJespecificacion) throws SQLException {

        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();

        PreparedStatement sentencia;

        try {

            String Query = "INSERT INTO especificacion (descripcion, iddetalle_venta)" + "VALUES (?, ?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, OBJespecificacion.getDescripcion());
            sentencia.setInt(2, OBJespecificacion.getIddetalle_venta());

            sentencia.execute();
            miRespuesta = "";

        } catch (Exception ex) {

            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error especificacionDAO\n" + ex.getMessage());

        }
        return miRespuesta;
    }

    public especificacion consultarEspecificacion(int idespecificacion) {
        especificacion miEspecificacion = null;

        // ESTABLECER LA CONEXION
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        // RECIBIR UN PARAMETRO DE CONSULTA idespecificacion PARA PODER RECUPERAR LA INFORMACION 

        try {
            Statement sentencia = nuevaCon.createStatement();
            // DEFINIR EL ORDEN DE LA BÚSQUEDA 
            String querySQL = "select idespecificacion, descripcion "
                    + "from especificacion where idespecificacion = '" + idespecificacion + "';";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                // ASIGNAMOS LOS RESULTADOS DE LA BÚSQUEDA AL OBJETO
                miEspecificacion = new especificacion();
                miEspecificacion.setIdespecificacion(rs.getInt(1));
                miEspecificacion.setDescripcion(rs.getString(2));

            }
            return miEspecificacion;
        } catch (Exception ex) {
            System.out.println("Ocurrió un error en EspecificacionDAOConsultarEspecificacion : " + ex.getMessage());
            return miEspecificacion;
        }

    }

    public String actualizarEspecificacion(especificacion OBJespecificacion) {

        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        // PREPARACION DE LA CONSULTA A EJECUTAR

        PreparedStatement sentencia;

        try {
            String Query = "UPDATE especificacion SET descripcion = ?"
                    + " where idespecificacion = ?;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, OBJespecificacion.getDescripcion());
            sentencia.setInt(2, OBJespecificacion.getIdespecificacion());
            sentencia.executeUpdate();
            miRespuesta = "";

        } catch (Exception ex) {

            miRespuesta = ex.getMessage();
            System.out.println("OCURRIO UN ERROR EN especificacionDAO.actualizarEspecificacion" + ex.getMessage());
        }
        return miRespuesta;
    }

    public ArrayList<especificacion> consultarListadoEspecificacion(int idespecificacion, String descripcion) {
        ArrayList<especificacion> misListadosEspecificacion = new ArrayList<especificacion>();
        especificacion misespecificaciones;

        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();

        //RECIBIR LOS CRITERIOS DE CONSULTA idEspecificacion PARA RECUPERAR LA INFORMACION
        try {
            Statement sentencia = nuevaCon.createStatement();
            // DEFINIR ORDEN BUSQUEDAS
            String querySQL = "select idespecificacion, descripcion"
                    + " from especificacion where idespecificacion like '%" + idespecificacion + "%'"
                    + " or (descripcion) like ('%" + descripcion + "%')order by idespecificacion;";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                misespecificaciones = new especificacion();
                misespecificaciones.setIdespecificacion(rs.getInt(1));
                misespecificaciones.setDescripcion(rs.getString(2));
                misListadosEspecificacion.add(misespecificaciones);
            }
            return misListadosEspecificacion;

        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error en especificacionDAO.ConsultarListadoEspecificacion" + ex.getMessage());
        }
        return misListadosEspecificacion;
    }

    public String eliminarEspecificacion(especificacion OBJespecificacion) {
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();

        PreparedStatement sentencia;

        try {
            String Query = " delete from especificacion where descripcion = ? and idespecificacion = ? ;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, OBJespecificacion.getDescripcion());
            sentencia.setInt(2, OBJespecificacion.getIdespecificacion());
            sentencia.execute();
            miRespuesta = "";

        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error en especificacionDAO.eliminarEspecificacion" + ex.getMessage());
        }
        return miRespuesta;
    }
}