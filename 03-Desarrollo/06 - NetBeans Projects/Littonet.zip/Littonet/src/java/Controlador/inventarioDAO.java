/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.inventario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
/**
 *
 * @author David
 */
public class inventarioDAO {
   
    public String adicionar_inventario (inventario inventarios) throws SQLException{
    
            String mi_respuesta;
            conexion mi_conexion = new conexion ();
            Connection nueva_con;
            nueva_con = mi_conexion.getConn();
            
            PreparedStatement sentencia;
            try{
                
                String Query = "  INSERT INTO inventario (entrada, salida, saldo, producto_idproducto)" + "VALUES (?,?,?,?);";
                sentencia = nueva_con.prepareStatement(Query);
                sentencia.setString(1, inventarios.getEntrada());
                sentencia.setString(2, inventarios.getSalida());
                sentencia.setInt(3, inventarios.getSaldo());
                sentencia.setInt(4, inventarios.getProducto_idproducto());
                                
                sentencia.execute();
                mi_respuesta = "";
                
            }catch (Exception ex) {
                
                mi_respuesta = ex.getMessage();
                    System.err.println("  Ocurrió un error en inventarioDAO\n " + ex.getMessage ());                                    
                    
            }
            
            return mi_respuesta; 
    }
    
    public inventario consultar_inventario (int id_inventario){
        // MÉTODO PARA CONSULTAR UN DATO DE LA BD ╦
        inventario mi_inventario = null;
        
        //ESTABLECER LA CONEXION ╦
        String mi_respuesta;
        conexion mi_conexion = new conexion ();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        //RECIBIR UN PAÁMETRO DE CONSULTA (ID) PARA PODER RETORNAR LA INFORMACIÓN ╦
        
        try{
            Statement sentencia  = nueva_con.createStatement();
            
            //DEFINIMOS EL ORDEN DE BUSQUEDA ╦
            String querySQL = " select idinventario, entrada, salida, saldo, producto_idproducto " +
                              " from inventario where idinventario = '" + id_inventario + "';"; 
            ResultSet rs= sentencia.executeQuery(querySQL);
            
            while (rs.next()){
            //ASIGNAMOS LOS RESULTADOS DE LA BUSQUEDA AL OBJETO QUE VA A RETONRNAR LA INFOMARCIÓN ╦
            mi_inventario = new inventario();
            mi_inventario.setIdinventario(rs.getInt(1));           
            mi_inventario.setEntrada(rs.getString(2));
            mi_inventario.setSalida(rs.getString(3));
            mi_inventario.setSaldo(rs.getInt(4));
            mi_inventario.setProducto_idproducto(rs.getInt(5));
            }  
            return mi_inventario;
        }
        
        catch(Exception ex){
            System.out.println(" Ha ocurrido un error en inventarioDAOConsulta: " + ex.getMessage());
            return mi_inventario;
        }
        //return mi_respuesta;
    }

    public String actualizar_producto (inventario inventarios){
        
        //ESTABLECER LA CONEXION ╦
        String mi_respuesta;
        conexion mi_conexion = new conexion ();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        //PREPARACION DE LA CONSULTA A EJECUTAR ╦
        PreparedStatement sentencia;
        try{
            String Query = " update inventario set entrada = ?, salida = ?, saldo = ?, producto_idproducto = ? " +
                           " where idinventario = ?;";
            sentencia = nueva_con.prepareStatement(Query);                        
            sentencia.setString(1, inventarios.getEntrada());
            sentencia.setString(2, inventarios.getSalida());
            sentencia.setInt(3, inventarios.getSaldo());
            sentencia.setInt(4, inventarios.getProducto_idproducto());
            sentencia.setInt(5, inventarios.getIdinventario());        
            sentencia.executeUpdate();
            
            mi_respuesta= "";
        }
        catch (Exception ex) {
                mi_respuesta = ex.getMessage();
                    System.err.println("  Ocurrió un error en inventarioDAO.Actualizar\n " + ex.getMessage ());                                    
        }
        return mi_respuesta;     
    }

    public ArrayList<inventario> consultar_listado_inventario(int idinventario, String entrada, String salida, int saldo, int producto_idproducto){
        
        ArrayList<inventario> mi_listado_inventario = new ArrayList<inventario>();
        inventario mi_inventario;
    
        String mi_respuesta;
        conexion mi_conexion = new conexion();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        //RECIBIMOS CRITERIOS DE CONSULTA DE LA CLASE DAO QUE RECUPERA LA INFORMACIÓN ╦
        try {
            Statement sentencia = nueva_con.createStatement(); 
            //DEFINIR ORDEN DE BUSQUEDAS 
            String querySQL = " select idinventario, entrada, salida, saldo, producto_idproducto " + 
                              " from inventario where idinventario like '% " + idinventario + "%'" +
                              " or (entrada) like ('%" + entrada + "%') or (salida) like ('%" + salida + "%') or (saldo) like ('%" + saldo + "%') " + 
                              " or (producto_idproducto) like ('%" + producto_idproducto + "%') ORDER BY idinventario;"; 
            
            ResultSet rs = sentencia.executeQuery(querySQL); 
            
            while (rs.next()){
            //ASIGNAMOS LOS RESULTADOS DE LA BUSQUEDA AL OBJETO QUE VA A RETONRNAR LA INFOMARCIÓN ╦
            mi_inventario = new inventario();
            mi_inventario.setIdinventario(rs.getInt(1));
            mi_inventario.setEntrada(rs.getString(2));
            mi_inventario.setSalida(rs.getString(3));
            mi_inventario.setSaldo(rs.getInt(4));     
            mi_inventario.setProducto_idproducto(rs.getInt(5));
            
            mi_listado_inventario.add(mi_inventario);
            }  
            return mi_listado_inventario;
        }
        catch(Exception ex){
            System.err.println(" Ha ocurrido un error en inventarioDAOConsultarListado: " + ex.getMessage());
            return mi_listado_inventario;
        } 
    }

    public String borrar_inventario (inventario inventarios){
        
    String mi_respuesta;
        conexion mi_conexion = new conexion();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        PreparedStatement sentencia;
    try{
        String Query = " delete from inventario where entrada = ? and salida = ? and saldo = ? and producto_idproducto = ? and  idinventario = ? ;";
        
        sentencia = nueva_con.prepareStatement(Query);
        sentencia.setString(1,inventarios.getEntrada());
        sentencia.setString(2,inventarios.getSalida());
        sentencia.setInt(3,inventarios.getSaldo());
        sentencia.setInt(4,inventarios.getProducto_idproducto());
        sentencia.setInt(5,inventarios.getIdinventario());
        
        sentencia.execute();
        
        mi_respuesta = " ";                               
    }
    catch(Exception ex){
    mi_respuesta = ex.getMessage();
            System.err.println(" Ha ocurrido un error en inventarioDAOBorrar: "+ex.getMessage());            
    }
    return mi_respuesta;
    }
}
