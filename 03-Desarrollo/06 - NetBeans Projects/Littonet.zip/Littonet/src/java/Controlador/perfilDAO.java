/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.perfil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class perfilDAO {

    public String adicionarperfil(perfil perfiles) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;
        try {
            String Query = "INSERT INTO perfil (descripcion)" + "values (?);";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, perfiles.getDescripcion());
            sentencia.execute();
            respuesta = "";
        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error AdicionarperfilesDAO\n" + ex.getMessage());
        }

        return respuesta;
    }

    public perfil consultaperfil(int idperfil) throws SQLException {
        perfil perfiles = null;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idperfil, descripcion "
                    + "from perfil where idperfil = '" + idperfil + "';";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                perfiles = new perfil();
                perfiles.setIdperfil(rs.getInt(1));
                perfiles.setDescripcion(rs.getString(2));
            }

            return perfiles;

        } catch (Exception ex) {
            System.err.println("Ocurrio un error en ConsultaperfilesDAO\n" + ex.getMessage());
            return perfiles;
        }
    }

    public String actualizarperfil(perfil perfiles) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();
        PreparedStatement sentencia;

        try {
            String Query = "update perfil set descripcion = ?"
                    + "where idperfil = ?;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, perfiles.getDescripcion());
            sentencia.setInt(2, perfiles.getIdperfil());
            sentencia.executeUpdate();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ActualizarperfilesDAO\n" + ex.getMessage());
        }
        return respuesta;
    }

    public ArrayList<perfil> consultarlistaperfil(int idperfil, String descripcion) throws SQLException {
        ArrayList<perfil> listadoperfiles = new ArrayList<perfil>();
        perfil perfiles;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idperfil, descripcion"
                    + " From perfil where idperfil like '%" + idperfil + "%'"
                    + " or (descripcion) like ('%" + descripcion + "%')order by idperfil;";

            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {

                perfiles = new perfil();
                perfiles.setIdperfil(rs.getInt(1));
                perfiles.setDescripcion(rs.getString(2));
                listadoperfiles.add(perfiles);

            }
            return listadoperfiles;
        } catch (Exception ex) {
            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ConsultarlistaperfilesDAO\n");
        }
        return listadoperfiles;
    }
    
    public String deleteperfil(perfil perfiles) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;

        try {
            String Query = "delete from perfil where descripcion = ? and idperfil = ? ;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, perfiles.getDescripcion());
            sentencia.setInt(2, perfiles.getIdperfil());
            sentencia.execute();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en deleteperfilesDAO\n" + ex.getMessage());
        }
        return respuesta;

    }
}
