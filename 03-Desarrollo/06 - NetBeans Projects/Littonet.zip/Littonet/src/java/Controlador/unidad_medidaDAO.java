/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.unidad_medida;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author David
 */
public class unidad_medidaDAO {
    // METODO ADICIONAR DESCRIPCIÓN 
    
    public String adicionar_unidad_medida (unidad_medida unidad_de_medida) throws SQLException{
    
            String mi_respuesta;
            conexion mi_conexion = new conexion ();
            Connection nueva_con;
            nueva_con = mi_conexion.getConn();
            
            PreparedStatement sentencia;
            try{
                String Query = "  INSERT INTO unidad_medida (descripcion)" + "VALUES (?)";
                sentencia = nueva_con.prepareStatement(Query);
                sentencia.setString(1, unidad_de_medida.getDescripcion());
                sentencia.execute();
                mi_respuesta = "";
                
            }
            catch (Exception ex) {
                mi_respuesta = ex.getMessage();
                    System.err.println("  Ocurrió un error en unidad_mediaDAO\n " + ex.getMessage ());                                    
            }
            return mi_respuesta; 
    }

    public unidad_medida consultar_unidad_medida (int id_unidad_medida){
        // MÉTODO PARA CONSULTAR UN DATO DE LA BD ╦
        unidad_medida mi_unidad_medida = null;
        
        //ESTABLECER LA CONEXION ╦
        String mi_respuesta;
        conexion mi_conexion = new conexion ();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        //RECIBIR UN PAÁMETRO DE CONSULTA (ID) PARA PODER RETORNAR LA INFORMACIÓN ╦
        
        try{
            Statement sentencia  = nueva_con.createStatement();
            
            //DEFINIMOS EL ORDEN DE BUSQUEDA ╦
            String querySQL = " select idunidad_medida, descripcion " +
                              " from unidad_medida where idunidad_medida = '" + id_unidad_medida +"';"; 
            ResultSet rs= sentencia.executeQuery(querySQL);
            
            while (rs.next()){
            //ASIGNAMOS LOS RESULTADOS DE LA BUSQUEDA AL OBJETO QUE VA A RETONRNAR LA INFOMARCIÓN ╦
            mi_unidad_medida = new unidad_medida();
            mi_unidad_medida.setIdunidad_medida(rs.getInt(1));
            mi_unidad_medida.setDescripcion(rs.getString(2));
            }  
            return mi_unidad_medida;
        }
        
        catch(Exception ex){
            System.err.println(" Ha ocurrido un error en unidad_medidadDAOConsulta: "+ex.getMessage());
            return mi_unidad_medida;
        }
        //return mi_respuesta;
    }
    
    public String actualizar_unidad_medida (unidad_medida unidad_de_medida){
        
        //ESTABLECER LA CONEXION ╦
        String mi_respuesta;
        conexion mi_conexion = new conexion ();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        //PREPARACION DE LA CONSULTA A EJECUTAR ╦
        PreparedStatement sentencia;
        try{
            String Query = " update unidad_medida set descripcion = ? " +
                           " where idunidad_medida = ?;";
            sentencia = nueva_con.prepareStatement(Query);            
            sentencia.setString(1, unidad_de_medida.getDescripcion());
            sentencia.setInt(2, unidad_de_medida.getIdunidad_medida());        
            sentencia.executeUpdate();
            
            mi_respuesta= "";
        }
        catch (Exception ex) {
                mi_respuesta = ex.getMessage();
                    System.err.println("  Ocurrió un error en unidad_mediaDAO.Actualizar\n " + ex.getMessage ());                                    
        }
        return mi_respuesta; 
    
    }

    public ArrayList<unidad_medida> consultar_listado_unidad(int idunidad_medida, String descripcion){
        
        ArrayList<unidad_medida> mi_listado_unidad_medida = new ArrayList<unidad_medida>();
        unidad_medida mi_unidad_medida;
    
        String mi_respuesta;
        conexion mi_conexion = new conexion();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        //RECIBIMOS CRITERIOS DE CONSULTA DE LA CLASE DAO QUE RECUPERA LA INFORMACIÓN ╦
        try {
            Statement sentencia = nueva_con.createStatement(); 
            //DEFINIR ORDEN DE BUSQUEDAS 
            String querySQL = " select idunidad_medida, descripcion " + 
                              " from unidad_medida where idunidad_medida like '% " + idunidad_medida + "%'" +
                              " or (descripcion) like ('%" + descripcion + "%') ORDER BY idunidad_medida;"; 
            ResultSet rs = sentencia.executeQuery(querySQL); 
            
            while (rs.next()){
            //ASIGNAMOS LOS RESULTADOS DE LA BUSQUEDA AL OBJETO QUE VA A RETONRNAR LA INFOMARCIÓN ╦
            mi_unidad_medida = new unidad_medida();
            mi_unidad_medida.setIdunidad_medida(rs.getInt(1));
            mi_unidad_medida.setDescripcion(rs.getString(2));
            mi_listado_unidad_medida.add(mi_unidad_medida);
            }  
            return mi_listado_unidad_medida;
        }
        catch(Exception ex){
            System.err.println(" Ha ocurrido un error en unidad_medidadDAOConsultarListado: "+ex.getMessage());
            return mi_listado_unidad_medida;
        } 
    } 

    public String borrar_unidad_medida (unidad_medida unidad_de_medida){
        
    String mi_respuesta;
        conexion mi_conexion = new conexion();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        PreparedStatement sentencia;
    try{
        String Query = " delete from unidad_medida where descripcion = ? and idunidad_medida = ? ;";
        
        sentencia = nueva_con.prepareStatement(Query);
        sentencia.setString(1,unidad_de_medida.getDescripcion());
        sentencia.setInt(2,unidad_de_medida.getIdunidad_medida());
        
        sentencia.execute();
        
        mi_respuesta = " ";                               
    }
    catch(Exception ex){
    mi_respuesta = ex.getMessage();
            System.err.println(" Ha ocurrido un error en unidad_medidadDAOBorrar: "+ex.getMessage());            
    }
    return mi_respuesta;
    }      
}   
