/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.detalle_venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author andre
 */
public class detalle_ventaDAO {

    //METODO ADICIONAR DETALLES DE LA CABECERA
    public String adicionardetalle_venta(detalle_venta OBJdetalle_venta) throws SQLException {

        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();

        PreparedStatement sentencia;

        try {

            String Query = "INSERT INTO detalle_venta (cantidad, estado_idestado, tipo_envio_idtipo_envio, medio_pago_idmedio_pago, producto_idproducto, especificacion_idespecificacion)" + "VALUES (?,?,?,?,?,?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setInt(1, OBJdetalle_venta.getCantidad());
            sentencia.setInt(2, OBJdetalle_venta.getEstado_idestado());
            sentencia.setInt(3, OBJdetalle_venta.getTipo_envio_idtipo_envio());
            sentencia.setInt(4, OBJdetalle_venta.getMedio_pago_idmedio_pago());
            sentencia.setInt(5, OBJdetalle_venta.getProducto_idproducto());
            sentencia.setInt(6, OBJdetalle_venta.getEspecificacion_idespecificacion());
            sentencia.execute();
            miRespuesta = "";

        } catch (Exception ex) {

            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error detalle_ventaDAO\n" + ex.getMessage());

        }
        return miRespuesta;
    }

    public detalle_venta consultarDetalle_venta(int iddetalle_venta) {
        detalle_venta miDetalle_venta = null;

        // ESTABLECER LA CONEXION
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        // RECIBIR UN PARAMETRO DE CONSULTA iddetalle_venta PARA PODER RECUPERAR LA INFORMACION 

        try {
            Statement sentencia = nuevaCon.createStatement();
            // DEFINIR EL ORDEN DE LA BÚSQUEDA 
            String querySQL = "select iddetalle_venta, cantidad, estado_idestado, tipo_envio_idtipo_envio, medio_pago_idmedio_pago, producto_idproducto, especificacion_idespecificacion "
                    + "from detalle_venta where iddetalle_venta = '" + iddetalle_venta + "';";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                // ASIGNAMOS LOS RESULTADOS DE LA BÚSQUEDA AL OBJETO
                miDetalle_venta = new detalle_venta();
                miDetalle_venta.setIddetalle_venta(rs.getInt(1));
                miDetalle_venta.setCantidad(rs.getInt(2));
                miDetalle_venta.setEstado_idestado(rs.getInt(3));
                miDetalle_venta.setTipo_envio_idtipo_envio(rs.getInt(4));
                miDetalle_venta.setMedio_pago_idmedio_pago(rs.getInt(5));
                miDetalle_venta.setProducto_idproducto(rs.getInt(6));
                miDetalle_venta.setEspecificacion_idespecificacion(rs.getInt(7));
            }
            return miDetalle_venta;
        } catch (Exception ex) {
            System.out.println("Ocurrió un error en detalle_ventaDAOConsultarDetalle_venta : " + ex.getMessage());
            return miDetalle_venta;
        }

    }

    public String actualizarDetalle_venta(detalle_venta OBJdetalle_venta) {

        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        // PREPARACION DE LA CONSULTA A EJECUTAR

        PreparedStatement sentencia;

        try {
            String Query = "UPDATE detalle_venta SET cantidad = ?, estado_idestado = ?, tipo_envio_idtipo_envio = ?, medio_pago_idmedio_pago = ?, producto_idproducto = ?, especificacion_idespecificacion = ? "
                    + " where iddetalle_venta = ?;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setInt(1, OBJdetalle_venta.getCantidad());
            sentencia.setInt(2, OBJdetalle_venta.getEstado_idestado());
            sentencia.setInt(3, OBJdetalle_venta.getTipo_envio_idtipo_envio());
            sentencia.setInt(4, OBJdetalle_venta.getMedio_pago_idmedio_pago());
            sentencia.setInt(5, OBJdetalle_venta.getProducto_idproducto());
            sentencia.setInt(6, OBJdetalle_venta.getEspecificacion_idespecificacion());
            sentencia.setInt(7, OBJdetalle_venta.getIddetalle_venta());
            
            sentencia.executeUpdate();
            miRespuesta = "";

        } catch (Exception ex) {

            miRespuesta = ex.getMessage();
            System.out.println("OCURRIO UN ERROR EN detalle_ventaDAO.actualizarDetalle_venta" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    public  ArrayList <detalle_venta> consultarListadoDetalle_venta (int iddetalle_venta, int cantidad, int estado_idestado, int tipo_envio_idtipo_envio,  int medio_pago_idmedio_pago,int producto_idproducto,int especificacion_idespecificacion){
        ArrayList<detalle_venta> misListadosDetalle_venta = new ArrayList<detalle_venta>();
        detalle_venta misdetalles_venta;
        
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        //RECIBIR LOS CRITERIOS DE CONSULTA iddetalle_venta PARA RECUPERAR LA INFORMACION
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            // DEFINIR ORDEN BUSQUEDAS
            String querySQL = "select iddetalle_venta, cantidad, estado_idestado, tipo_envio_idtipo_envio, medio_pago_idmedio_pago, producto_idproducto, especificacion_idespecificacion" + 
                    " from detalle_venta where iddetalle_venta like '%" + iddetalle_venta + "%'" + 
                    " or (cantidad) like ('%" + cantidad + "%') or (estado_idestado) like ('%" + estado_idestado + "%') or (tipo_envio_idtipo_envio) like ('%" + tipo_envio_idtipo_envio + "%') "
                    + "or (medio_pago_idmedio_pago) like ('%" + medio_pago_idmedio_pago + "%') "
                    + "or (producto_idproducto) like ('%" + producto_idproducto + "%') "
                    + "or (especificacion_idespecificacion) like ('%" + especificacion_idespecificacion + "%') order by iddetalle_venta;";
            ResultSet rs = sentencia.executeQuery(querySQL);
            
            while (rs.next()) {
                misdetalles_venta = new detalle_venta();
                misdetalles_venta.setIddetalle_venta(rs.getInt(1));
                misdetalles_venta.setCantidad(rs.getInt(2));
                misdetalles_venta.setEstado_idestado(rs.getInt(3));
                misdetalles_venta.setTipo_envio_idtipo_envio(rs.getInt(4));
                misdetalles_venta.setMedio_pago_idmedio_pago(rs.getInt(5));
                misdetalles_venta.setProducto_idproducto(rs.getInt(6));
                misdetalles_venta.setEspecificacion_idespecificacion(rs.getInt(7));
                misListadosDetalle_venta.add(misdetalles_venta);
            }
            return misListadosDetalle_venta;
            
        } catch (Exception ex) { 
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error en detalle_ventaDAO.ConsultarListadoDetalle_venta" + ex.getMessage());
        }
        return misListadosDetalle_venta;
    }
    
    public String eliminarDetalle_venta (detalle_venta OBJdetalle_venta) {
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        
        
    try { 
        String Query = " delete from detalle_venta where cantidad = ? and estado_idestado = ? and tipo_envio_idtipo_envio = ? and medio_pago_idmedio_pago = ? and producto_idproducto = ? and especificacion_idespecificacion = ? and iddetalle_venta = ? ;";
        sentencia = nuevaCon.prepareStatement(Query);
        sentencia.setInt(1, OBJdetalle_venta.getCantidad());
        sentencia.setInt(2, OBJdetalle_venta.getEstado_idestado());
        sentencia.setInt(3, OBJdetalle_venta.getTipo_envio_idtipo_envio());
        sentencia.setInt(4, OBJdetalle_venta.getMedio_pago_idmedio_pago());
        sentencia.setInt(5, OBJdetalle_venta.getProducto_idproducto());
        sentencia.setInt(6, OBJdetalle_venta.getEspecificacion_idespecificacion());
        sentencia.setInt(7, OBJdetalle_venta.getIddetalle_venta());
        sentencia.execute();
        miRespuesta = "";
        
    } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrió un error en detalle_ventaDAO.eliminarDetalle_venta" + ex.getMessage());
    }
        return miRespuesta;
    }
}