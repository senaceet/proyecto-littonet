/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
/**
 *
 * @author David
 */
public class productoDAO {
    
    public String adicionar_producto (producto productos) throws SQLException{
    
            String mi_respuesta;
            conexion mi_conexion = new conexion ();
            Connection nueva_con;
            nueva_con = mi_conexion.getConn();
            
            PreparedStatement sentencia;
            try{
                
                String Query = "  INSERT INTO producto (precio, imagen, caracteristicas, unidad_medida_idunidad_medida, categoria_idcategoria  )" + "VALUES (?,?,?,?,?);";
                sentencia = nueva_con.prepareStatement(Query);
                sentencia.setInt(1, productos.getPrecio());
                sentencia.setString(2, productos.getImagen());
                sentencia.setString(3, productos.getCaracteristicas());
                sentencia.setInt(4, productos.getUnidad_medida_idunidad_medida());
                sentencia.setInt(5, productos.getCategoria_idcategoria());
                
                sentencia.execute();
                mi_respuesta = "";
                
            }catch (Exception ex) {
                
                mi_respuesta = ex.getMessage();
                    System.err.println("  Ocurrió un error en productoDAO\n " + ex.getMessage ());                                    
                    
            }
            
            return mi_respuesta; 
    }
    
    public producto consultar_producto (int id_producto){
        // MÉTODO PARA CONSULTAR UN DATO DE LA BD ╦
        producto mi_producto = null;
        
        //ESTABLECER LA CONEXION ╦
        String mi_respuesta;
        conexion mi_conexion = new conexion ();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        //RECIBIR UN PAÁMETRO DE CONSULTA (ID) PARA PODER RETORNAR LA INFORMACIÓN ╦
        
        try{
            Statement sentencia  = nueva_con.createStatement();
            
            //DEFINIMOS EL ORDEN DE BUSQUEDA ╦
            String querySQL = " select idproducto, precio, imagen, caracteristicas, unidad_medida_idunidad_medida, categoria_idcategoria " +
                              " from producto where idproducto = '" + id_producto +"';"; 
            ResultSet rs= sentencia.executeQuery(querySQL);
            
            while (rs.next()){
            //ASIGNAMOS LOS RESULTADOS DE LA BUSQUEDA AL OBJETO QUE VA A RETONRNAR LA INFOMARCIÓN ╦
            mi_producto = new producto();
            mi_producto.setIdproducto(rs.getInt(1));
            mi_producto.setPrecio(rs.getInt(2));
            mi_producto.setImagen(rs.getString(3));
            mi_producto.setCaracteristicas(rs.getString(4));
            mi_producto.setUnidad_medida_idunidad_medida(rs.getInt(5));
            mi_producto.setCategoria_idcategoria(rs.getInt(6));
            }  
            return mi_producto;
        }
        
        catch(Exception ex){
            System.out.println(" Ha ocurrido un error en productoDAOConsulta: "+ex.getMessage());
            return mi_producto;
        }
        //return mi_respuesta;
    }

    public String actualizar_producto (producto productos){
        
        //ESTABLECER LA CONEXION ╦
        String mi_respuesta;
        conexion mi_conexion = new conexion ();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        //PREPARACION DE LA CONSULTA A EJECUTAR ╦
        PreparedStatement sentencia;
        try{
            String Query = " update producto set precio = ?, imagen = ?, caracteristicas = ?, unidad_medida_idunidad_medida = ?, categoria_idcategoria = ? " +
                           " where idproducto = ?;";
            sentencia = nueva_con.prepareStatement(Query);            
            sentencia.setInt(1, productos.getPrecio());
            sentencia.setString(2, productos.getImagen());
            sentencia.setString(3, productos.getCaracteristicas());
            sentencia.setInt(4, productos.getUnidad_medida_idunidad_medida());
            sentencia.setInt(5, productos.getCategoria_idcategoria());
            sentencia.setInt(6, productos.getIdproducto());        
            sentencia.executeUpdate();
            
            mi_respuesta= "";
        }
        catch (Exception ex) {
                mi_respuesta = ex.getMessage();
                    System.err.println("  Ocurrió un error en productoDAO.Actualizar\n " + ex.getMessage ());                                    
        }
        return mi_respuesta;     
    }

    public ArrayList<producto> consultar_listado_producto(int idproducto, int precio, String imagen, String caracteristicas, int unidad_medida_idunidad_medida, int categoria_idcategoria){
        
        ArrayList<producto> mi_listado_producto = new ArrayList<producto>();
        producto mi_producto;
    
        String mi_respuesta;
        conexion mi_conexion = new conexion();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        //RECIBIMOS CRITERIOS DE CONSULTA DE LA CLASE DAO QUE RECUPERA LA INFORMACIÓN ╦
        try {
            Statement sentencia = nueva_con.createStatement(); 
            //DEFINIR ORDEN DE BUSQUEDAS 
            String querySQL = " select idproducto, precio, imagen, caracteristicas, unidad_medida_idunidad_medida, categoria_idcategoria " + 
                              " from producto where idproducto like '% " + idproducto + "%'" +
                              " or (precio) like ('%" + precio + "%') or (imagen) like ('%" + imagen + "%') or (caracteristicas) like ('%" + caracteristicas + "%') " + 
                              " or (unidad_medida_idunidad_medida) like ('%" + unidad_medida_idunidad_medida + "%') or (categoria_idcategoria) like ('%" + categoria_idcategoria + "%') ORDER BY idproducto;"; 
            
            ResultSet rs = sentencia.executeQuery(querySQL); 
            
            while (rs.next()){
            //ASIGNAMOS LOS RESULTADOS DE LA BUSQUEDA AL OBJETO QUE VA A RETONRNAR LA INFOMARCIÓN ╦
            mi_producto = new producto();
            mi_producto.setIdproducto(rs.getInt(1));
            mi_producto.setPrecio(rs.getInt(2));
            mi_producto.setImagen(rs.getString(3));
            mi_producto.setCaracteristicas(rs.getString(4));
            mi_producto.setUnidad_medida_idunidad_medida(rs.getInt(5));
            mi_producto.setCategoria_idcategoria(rs.getInt(6));
            
            mi_listado_producto.add(mi_producto);
            }  
            return mi_listado_producto;
        }
        catch(Exception ex){
            System.err.println(" Ha ocurrido un error en productoDAOConsultarListado: " + ex.getMessage());
            return mi_listado_producto;
        } 
    }

    public String borrar_producto (producto productos){
        
    String mi_respuesta;
        conexion mi_conexion = new conexion();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        PreparedStatement sentencia;
    try{
        String Query = " delete from producto where precio = ? and imagen = ? and caracteristicas = ? and unidad_medida_idunidad_medida = ? categoria_idcategoria = ? and  idproducto = ? ;";
        
        sentencia = nueva_con.prepareStatement(Query);
        sentencia.setInt(1,productos.getPrecio());
        sentencia.setString(2,productos.getImagen());
        sentencia.setString(3,productos.getCaracteristicas());
        sentencia.setInt(4,productos.getUnidad_medida_idunidad_medida());
        sentencia.setInt(5,productos.getCategoria_idcategoria());
        sentencia.setInt(6,productos.getIdproducto());
        
        sentencia.execute();
        
        mi_respuesta = " ";                               
    }
    catch(Exception ex){
    mi_respuesta = ex.getMessage();
            System.err.println(" Ha ocurrido un error en productoDAOBorrar: "+ex.getMessage());            
    }
    return mi_respuesta;
    }
}
