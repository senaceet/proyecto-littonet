/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Modelo.cabecera_venta;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author andre
 */
public class cabecera_ventaDAO {
    
   //METODO ADICIONAR TIPOS DE DOCUMENTO 2
    
    public String adicionarcabecera_venta (cabecera_venta OBJcabecera_venta) throws SQLException {
       
    
        String miRespuesta;
        conexion miConexion = new conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        
        try {
            
            String Query = "INSERT INTO cabecera_venta (fecha, referencia, usuario_idusuario, detalle_venta_iddetalle_venta, tipo_documento2_idtipo_documento2)" + "VALUES (?, ?, ?, ?, ?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, OBJcabecera_venta.getFecha());
            sentencia.setInt(2, OBJcabecera_venta.getReferencia());
            sentencia.setInt(3, OBJcabecera_venta.getUsuario_idusuario());
            sentencia.setInt(4, OBJcabecera_venta.getDetalle_venta_iddetalle_venta()); 
            sentencia.setInt (5, OBJcabecera_venta.getTipo_documento2_idtipo_documento2());
            sentencia.execute();
            miRespuesta = "";
            
          
        } catch (Exception ex){
            
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error cabecera_ventaDAO\n" + ex.getMessage());
            
        }
        return miRespuesta;
    }
    
    public cabecera_venta consultarCabecera_venta(int idcabecera_venta) {
        cabecera_venta miCabecera_venta = null;

        // ESTABLECER LA CONEXION
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        // RECIBIR UN PARAMETRO DE CONSULTA idcabecera_venta PARA PODER RECUPERAR LA INFORMACION 

        try {
            Statement sentencia = nuevaCon.createStatement();
            // DEFINIR EL ORDEN DE LA BÚSQUEDA 
            String querySQL = "select idcabecera_venta, fecha, referencia, usuario_idusuario, detalle_venta_iddetalle_venta "
                    + "from cabecera_venta where idcabecera_venta = '" + idcabecera_venta + "';";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                // ASIGNAMOS LOS RESULTADOS DE LA BÚSQUEDA AL OBJETO
                miCabecera_venta = new cabecera_venta();
                miCabecera_venta.setIdcabecera_venta(rs.getInt(1));
                miCabecera_venta.setFecha(rs.getString(2));
                miCabecera_venta.setReferencia(rs.getInt(3));
                miCabecera_venta.setUsuario_idusuario(rs.getInt(4));
                miCabecera_venta.setDetalle_venta_iddetalle_venta(rs.getInt(5));
                miCabecera_venta.setTipo_documento2_idtipo_documento2(rs.getInt(6));

            }
            return miCabecera_venta;
        } catch (Exception ex) {
            System.out.println("Ocurrió un error en cabecera_ventaDAOConsultarCabecera_venta : " + ex.getMessage());
            return miCabecera_venta;
        }

    }
    
    public String actualizarCabecera_venta(cabecera_venta OBJcabecera_venta) {

        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        // PREPARACION DE LA CONSULTA A EJECUTAR

        PreparedStatement sentencia;

        try {
            String Query = "UPDATE cabecera_venta SET fecha = ?, referencia = ?, usuario_idusuario = ?, detalle_venta_iddetalle_venta = ?, tipo_documento2_idtipo_documento2 = ?"
                    + " where idcabecera_venta = ?;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, OBJcabecera_venta.getFecha());
            sentencia.setInt(2, OBJcabecera_venta.getReferencia());
            sentencia.setInt(3, OBJcabecera_venta.getUsuario_idusuario());
            sentencia.setInt(4, OBJcabecera_venta.getDetalle_venta_iddetalle_venta());
            sentencia.setInt(5, OBJcabecera_venta.getTipo_documento2_idtipo_documento2());
            sentencia.setInt(6, OBJcabecera_venta.getIdcabecera_venta());
            sentencia.executeUpdate();
            miRespuesta = "";

        } catch (Exception ex) {

            miRespuesta = ex.getMessage();
            System.out.println("OCURRIO UN ERROR EN cabecera_ventaDAO.actualizarCabecera_venta" + ex.getMessage());
        }
        return miRespuesta;
    }

    public ArrayList<cabecera_venta> consultarListadoCabeceras_venta(int idcabecera_venta, String fecha, String referencia, int usuario_idusuario, int detalle_venta_iddetalle_venta, int tipo_documento2_idtipo_documento2) {
        ArrayList<cabecera_venta> misListadosCabeceras_venta = new ArrayList<cabecera_venta>();
        cabecera_venta miscabeceras_venta;

        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();

        //RECIBIR LOS CRITERIOS DE CONSULTA idEstado PARA RECUPERAR LA INFORMACION
        try {
            Statement sentencia = nuevaCon.createStatement();
            // DEFINIR ORDEN BUSQUEDAS
            String querySQL = "select idcabecera_venta, fecha, referencia, usuario_idusuario, detalle_venta_iddetalle_venta, tipo_documento2_idtipo_documento2"
                    + " from cabecera_venta where idcabecera_venta like '%" + idcabecera_venta + "%'"
                    + " or (fecha) like ('%" + fecha + "%') or (referencia) like ('%" + referencia + "%')"
                    + " or (usuario_idusuario) like ('%" + usuario_idusuario + "%') "
                    + "or (detalle_venta_iddetalle_venta) like ('%" + detalle_venta_iddetalle_venta + "%') "
                    + "or (tipo_documento2_idtipo_documento2) like ('%" + tipo_documento2_idtipo_documento2 + "%') order by idcabecera_venta;";

            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                miscabeceras_venta = new cabecera_venta();
                miscabeceras_venta.setIdcabecera_venta(rs.getInt(1));
                miscabeceras_venta.setFecha(rs.getString(2));
                miscabeceras_venta.setReferencia(rs.getInt(3));
                miscabeceras_venta.setUsuario_idusuario(rs.getInt(4));
                miscabeceras_venta.setDetalle_venta_iddetalle_venta(rs.getInt(5));
                miscabeceras_venta.setTipo_documento2_idtipo_documento2(rs.getInt(6));

                misListadosCabeceras_venta.add(miscabeceras_venta);
            }
            return misListadosCabeceras_venta;

        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error en cabecera_ventaDAO.ConsultarListadoCabeceras_venta" + ex.getMessage());
        }
        return misListadosCabeceras_venta;
    }

    public String eliminarCabecera_venta(cabecera_venta OBJcabecera_venta) {
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();

        PreparedStatement sentencia;

        try {
            String Query = " delete from cabecera_venta where fecha = ? and referencia = ? and usuario_idusuario = ? "
                    + "and detalle_venta_iddetalle_venta = ? and tipo_documento2_idtipo_documento2 = ? and idcabecera_venta = ? ;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, OBJcabecera_venta.getFecha());
            sentencia.setInt(2, OBJcabecera_venta.getReferencia());
            sentencia.setInt(3, OBJcabecera_venta.getUsuario_idusuario());
            sentencia.setInt(4, OBJcabecera_venta.getDetalle_venta_iddetalle_venta());
            sentencia.setInt(5, OBJcabecera_venta.getTipo_documento2_idtipo_documento2());
            sentencia.setInt(6, OBJcabecera_venta.getIdcabecera_venta());
            sentencia.execute();
            miRespuesta = "";

        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error en cabecera_ventaDAO.eliminarCabecera_venta" + ex.getMessage());
        }
        return miRespuesta;
    }
}
