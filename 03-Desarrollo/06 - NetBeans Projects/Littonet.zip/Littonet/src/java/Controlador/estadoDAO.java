/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import Modelo.estado;

/**
 *
 * @author andre
 */
public class estadoDAO {

    //METODO ADICIONAR TIPOS DE DOCUMENTO 2
    public String adicionarestado(estado OBJestado) throws SQLException {

        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();

        PreparedStatement sentencia;

        try {

            String Query = "INSERT INTO estado (descripcion)" + "VALUES (?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, OBJestado.getDescripcion());
            sentencia.execute();
            miRespuesta = "";

        } catch (Exception ex) {

            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error estadoDAO\n" + ex.getMessage());

        }
        return miRespuesta;
    }

    public estado consultarEstado(int idestado) {
        estado miEstado = null;

        // ESTABLECER LA CONEXION
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        // RECIBIR UN PARAMETRO DE CONSULTA idestado PARA PODER RECUPERAR LA INFORMACION 

        try {
            Statement sentencia = nuevaCon.createStatement();
            // DEFINIR EL ORDEN DE LA BÚSQUEDA 
            String querySQL = "select idestado, descripcion "
                    + "from estado where idestado = '" + idestado + "';";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                // ASIGNAMOS LOS RESULTADOS DE LA BÚSQUEDA AL OBJETO
                miEstado = new estado();
                miEstado.setIdestado(rs.getInt(1));
                miEstado.setDescripcion(rs.getString(2));

            }
            return miEstado;
        } catch (Exception ex) {
            System.out.println("Ocurrió un error en EstadoDAOConsultarEstado : " + ex.getMessage());
            return miEstado;
        }

    }

    public String actualizarEstado(estado OBJestado) {

        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        // PREPARACION DE LA CONSULTA A EJECUTAR

        PreparedStatement sentencia;

        try {
            String Query = "UPDATE estado SET descripcion = ?"
                    + " where idestado = ?;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, OBJestado.getDescripcion());
            sentencia.setInt(2, OBJestado.getIdestado());
            sentencia.executeUpdate();
            miRespuesta = "";

        } catch (Exception ex) {

            miRespuesta = ex.getMessage();
            System.out.println("OCURRIO UN ERROR EN estadoDAO.actualizarEstados" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    public  ArrayList <estado> consultarListadoEstados (int idestado, String descripcion){
        ArrayList<estado> misListadosEstados = new ArrayList<estado>();
        estado misestados;
        
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        //RECIBIR LOS CRITERIOS DE CONSULTA idEstado PARA RECUPERAR LA INFORMACION
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            // DEFINIR ORDEN BUSQUEDAS
            String querySQL = "select idestado, descripcion" + 
                    " from estado where idestado like '%" + idestado + "%'" + 
                    " or (descripcion) like ('%" + descripcion + "%')order by idestado;";
            ResultSet rs = sentencia.executeQuery(querySQL);
            
            while (rs.next()) {
                misestados = new estado();
                misestados.setIdestado(rs.getInt(1));
                misestados.setDescripcion(rs.getString(2));
                misListadosEstados.add(misestados);
            }
            return misListadosEstados;
            
        } catch (Exception ex) { 
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error en estadoDAO.ConsultarListadoEstados" + ex.getMessage());
        }
        return misListadosEstados;
    }
    
    public String eliminarEstado (estado OBJestado) {
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        
        
    try { 
        String Query = " delete from estado where descripcion = ? and idestado = ? ;";
        sentencia = nuevaCon.prepareStatement(Query);
        sentencia.setString(1, OBJestado.getDescripcion());
        sentencia.setInt(2, OBJestado.getIdestado());
        sentencia.execute();
        miRespuesta = "";
        
    } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrió un error en estadoDAO.eliminarEstado" + ex.getMessage());
    }
        return miRespuesta;
    }
}
