/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ciudad;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class ciudadDAO {

    public String adicionarciudad(ciudad ciudades) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;
        try {
            String Query = "INSERT INTO ciudad (descripcion)" + "values (?);";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, ciudades.getDescripcion());
            sentencia.execute();
            respuesta = "";
        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio error AdicionarciudadDAO\n" + ex.getMessage());
        }

        return respuesta;
    }

    public ciudad consultarciudad(int idciudad) throws SQLException {
        ciudad ciudades = null;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idciudad, descripcion "
                    + "from ciudad where idciudad = '" + idciudad + "';";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                ciudades = new ciudad();
                ciudades.setIdciudad(rs.getInt(1));
                ciudades.setDescripcion(rs.getString(2));
            }

            return ciudades;

        } catch (Exception ex) {
            System.err.println("Ocurrio un error en ConsultaciudadDAO\n" + ex.getMessage());
            return ciudades;
        }
    }

    public String actualizarciudad(ciudad ciudades) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();
        PreparedStatement sentencia;

        try {
            String Query = "update ciudad set descripcion = ?"
                    + "where idciudad = ?;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, ciudades.getDescripcion());
            sentencia.setInt(2, ciudades.getIdciudad());
            sentencia.executeUpdate();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ActualizarciudadDAO\n" + ex.getMessage());
        }
        return respuesta;
    }

    public ArrayList<ciudad> consultarlistaciudad(int idciudad, String descripcion) throws SQLException {
        ArrayList<ciudad> listadociudad = new ArrayList<ciudad>();
        ciudad ciudades;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idciudad, descripcion"
                    + " From ciudad where idciudad like '%" + idciudad + "%'"
                    + " or (descripcion) like ('%" + descripcion + "%')order by idciudad;";

            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {

                ciudades = new ciudad();
                ciudades.setIdciudad(rs.getInt(1));
                ciudades.setDescripcion(rs.getString(2));
                listadociudad.add(ciudades);

            }
            return listadociudad;
        } catch (Exception ex) {
            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ConsultarlistaciudadDAO\n");
        }
        return listadociudad;
    }

    public String deleteciudad(ciudad ciudades) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;

        try {
            String Query = "delete from ciudad where descripcion = ? and idciudad = ? ;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, ciudades.getDescripcion());
            sentencia.setInt(2, ciudades.getIdciudad());
            sentencia.execute();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en deleteciudadDAO\n" + ex.getMessage());
        }
        return respuesta;

    }
}
