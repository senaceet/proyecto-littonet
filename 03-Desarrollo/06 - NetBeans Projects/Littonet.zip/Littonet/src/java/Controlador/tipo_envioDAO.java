/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.tipo_envio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class tipo_envioDAO {

    /*METODO ADICIONAR PERFILES*/
    public String adicionarenvio(tipo_envio envio) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;
        try {
            String Query = "INSERT INTO tipo_envio (descripcion)" + "values (?);";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, envio.getDescripcion());
            sentencia.execute();
            respuesta = "";
        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error AdicionarenvioDAO\n" + ex.getMessage());
        }

        return respuesta;
    }

    public tipo_envio consultarenvio(int idtipo_envio) throws SQLException {
        tipo_envio envios = null;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idtipo_envio, descripcion "
                    + "from tipo_envio where idtipo_envio = '" + idtipo_envio + "';";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                envios = new tipo_envio();
                envios.setIdtipo_envio(rs.getInt(1));
                envios.setDescripcion(rs.getString(2));
            }

            return envios;

        } catch (Exception ex) {
            System.err.println("Ocurrio un error en ConsultaenvioDAO" + ex.getMessage());
            return envios;
        }
    }

    public String actualizarenvio(tipo_envio envio) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();
        PreparedStatement sentencia;

        try {
            String Query = "update tipo_envio set descripcion = ?"
                    + "where idtipo_envio = ?;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, envio.getDescripcion());
            sentencia.setInt(2, envio.getIdtipo_envio());
            sentencia.executeUpdate();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ActualizarenvioDAO" + ex.getMessage());
        }
        return respuesta;
    }
    
    public ArrayList<tipo_envio> consultarlistaenvio(int idtipo_envio, String descripcion) throws SQLException {
        ArrayList<tipo_envio> listadoenvios = new ArrayList<tipo_envio>();
        tipo_envio envios;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idtipo_envio, descripcion"
                    + " From tipo_envio where idtipo_envio like '%" + idtipo_envio + "%'"
                    + " or (descripcion) like ('%" + descripcion + "%')order by idtipo_envio;";

            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {

                envios = new tipo_envio();
                envios.setIdtipo_envio(rs.getInt(1));
                envios.setDescripcion(rs.getString(2));
                listadoenvios.add(envios);

            }
            return listadoenvios;
        } catch (Exception ex) {
            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ConsultarlistaenvioDAO\n");
        }
        return listadoenvios;
    }
    
     public String deleteenvio(tipo_envio envio) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;

        try {
            String Query = "delete from tipo_envio where descripcion = ? and idtipo_envio = ? ;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, envio.getDescripcion());
            sentencia.setInt(2, envio.getIdtipo_envio());
            sentencia.execute();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en deleteenvioDAO\n" + ex.getMessage());
        }
        return respuesta;

    }
}
