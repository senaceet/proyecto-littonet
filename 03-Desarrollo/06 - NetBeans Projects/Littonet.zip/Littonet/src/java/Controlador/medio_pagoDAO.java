/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.medio_pago;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class medio_pagoDAO {

    public String adicionarpago(medio_pago pago) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;
        try {
            String Query = "INSERT INTO medio_pago (descripcion)" + "values (?);";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, pago.getDescripcion());
            sentencia.execute();
            respuesta = "";
        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error AdicionarpagoDAO\n" + ex.getMessage());
        }

        return respuesta;
    }

    public medio_pago consultarpago(int idmedio_pago) throws SQLException {
        medio_pago pagos = null;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idmedio_pago, descripcion "
                    + "from medio_pago where idmedio_pago = '" + idmedio_pago + "';";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                pagos = new medio_pago();
                pagos.setIdmedio_pago(rs.getInt(1));
                pagos.setDescripcion(rs.getString(2));
            }

            return pagos;

        } catch (Exception ex) {
            System.err.println("Ocurrio un error en ConsultapagoDAO\n" + ex.getMessage());
            return pagos;
        }

    }

    public String actualizarpago(medio_pago pago) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();
        PreparedStatement sentencia;

        try {
            String Query = "update medio_pago set descripcion = ?"
                    + "where idmedio_pago = ?;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, pago.getDescripcion());
            sentencia.setInt(2, pago.getIdmedio_pago());
            sentencia.executeUpdate();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ActualizarpagoDAO\n" + ex.getMessage());
        }
        return respuesta;
    }

    public ArrayList<medio_pago> consultarlistapago(int idmedio_pago, String descripcion) throws SQLException {
        ArrayList<medio_pago> listadopagos = new ArrayList<medio_pago>();
        medio_pago pagos;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idmedio_pago, descripcion"
                    + " From medio_pago where idmedio_pago like '%" + idmedio_pago + "%'"
                    + " or (descripcion) like ('%" + descripcion + "%')order by idmedio_pago;";

            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {

                pagos = new medio_pago();
                pagos.setIdmedio_pago(rs.getInt(1));
                pagos.setDescripcion(rs.getString(2));
                listadopagos.add(pagos);

            }
            return listadopagos;
        } catch (Exception ex) {
            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ConsultarlistapagoDAO\n");
        }
        return listadopagos;
    }

    public String deletepago(medio_pago pago) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;

        try {
            String Query = "delete from medio_pago where descripcion = ? and idmedio_pago = ? ;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, pago.getDescripcion());
            sentencia.setInt(2, pago.getIdmedio_pago());
            sentencia.execute();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en deletepagoDAO\n" + ex.getMessage());
        }
        return respuesta;

    }
}
