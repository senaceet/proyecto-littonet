/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author David
 */
public class usuarioDAO {

    public String adicionarusuario(usuario usuarios) throws SQLException {

        String respuesta;
        conexion miConexion = new conexion();
        Connection nuevacon;
        nuevacon = miConexion.getConn();

        PreparedStatement sentencia;
        try {
            String Query = "INSERT INTO usuario (nombre, apellido, documento, celular, correo, direccion, username, clave, Ciudad_idciudad, Perfil_idperfil, Tipo_documento_idtipo_documento)" + "values (?,?,?,?,?,?,?,?,?,?,?);";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, usuarios.getNombre());
            sentencia.setString(2, usuarios.getApellido());
            sentencia.setString(3, usuarios.getDocumento());
            sentencia.setString(4, usuarios.getCelular());
            sentencia.setString(5, usuarios.getCorreo());
            sentencia.setString(6, usuarios.getDireccion());
            sentencia.setString(7, usuarios.getUsername());
            sentencia.setString(8, usuarios.getClave());
            sentencia.setInt(9, usuarios.getCiudad_idciudad());
            sentencia.setInt(10, usuarios.getPerfil_idperfil());
            sentencia.setInt(11, usuarios.getTipo_documento_idtipo_documento());

            sentencia.execute();
            respuesta = "";

        } catch (Exception ex) {
            respuesta = ex.getMessage();
            System.err.println("\"Ocurrio un error AdicionarusuarioDAO\n" + ex.getMessage());

        }
        return respuesta;
    }

    public usuario consultausuario(int idusuario) throws SQLException {
        usuario usuarios = null;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "SELECT idusuario, nombre, apellido, documento, celular, correo, direccion, username, clave, ciudad_idciudad, perfil_idperfil, tipo_documento_idtipo_documento "
                    + "FROM usuario WHERE idusuario = "  + idusuario + ";";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                usuarios = new usuario();
                usuarios.setIdusuario(rs.getInt(1));
                usuarios.setNombre(rs.getString(2));
                usuarios.setApellido(rs.getString(3));
                usuarios.setDocumento(rs.getString(4));
                usuarios.setCelular(rs.getString(5));
                usuarios.setCorreo(rs.getString(6));
                usuarios.setDireccion(rs.getString(7));
                usuarios.setUsername(rs.getString(8));
                usuarios.setClave(rs.getString(9));
                usuarios.setCiudad_idciudad(rs.getInt(10));
                usuarios.setPerfil_idperfil(rs.getInt(11));
                usuarios.setTipo_documento_idtipo_documento(rs.getInt(12));
            }

            return usuarios;

        } catch (Exception ex) {
            System.err.println("Ocurrio un error en ConsultausuarioDAO\n" + ex.getMessage());
            return usuarios;
        }
    }

    public usuario consulta_login(String username) throws SQLException {
        usuario usuarios = null;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "SELECT idusuario, nombre, apellido, documento, celular, correo, direccion, username, clave, ciudad_idciudad, perfil_idperfil, tipo_documento_idtipo_documento "
                    + "FROM usuario WHERE username = " + '"'+username+'"';
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                usuarios = new usuario();
                usuarios.setIdusuario(rs.getInt(1));
                usuarios.setNombre(rs.getString(2));
                usuarios.setApellido(rs.getString(3));
                usuarios.setDocumento(rs.getString(4));
                usuarios.setCelular(rs.getString(5));
                usuarios.setCorreo(rs.getString(6));
                usuarios.setDireccion(rs.getString(7));
                usuarios.setUsername(rs.getString(8));
                usuarios.setClave(rs.getString(9));
                usuarios.setCiudad_idciudad(rs.getInt(10));
                usuarios.setPerfil_idperfil(rs.getInt(11));
                usuarios.setTipo_documento_idtipo_documento(rs.getInt(12));
            }

            return usuarios;

        } catch (Exception ex) {
            System.err.println("Ocurrio un error en consulta_loginDAO\n" + ex.getMessage());
            return usuarios;
        }
    }
     
    public String actualizarusuario(usuario usuarios) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();
        PreparedStatement sentencia;

        try {
            String Query = "update usuarios set nombre = ?, apellido = ?, documento = ?, celular = ?, correo = ?, direccion = ?, username = ?, clave = ?, = ?, Ciudad_idciudad = ?, Perfil_idperfi = ?, Tipo_documento_idtipo_documento("
                    + "where idusuario = ?;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, usuarios.getNombre());
            sentencia.setString(2, usuarios.getApellido());
            sentencia.setString(3, usuarios.getDocumento());
            sentencia.setString(4, usuarios.getCelular());
            sentencia.setString(5, usuarios.getCorreo());
            sentencia.setString(6, usuarios.getDireccion());
            sentencia.setString(7, usuarios.getUsername());
            sentencia.setString(8, usuarios.getClave());
            sentencia.setInt(9, usuarios.getCiudad_idciudad());
            sentencia.setInt(10, usuarios.getPerfil_idperfil());
            sentencia.setInt(11, usuarios.getTipo_documento_idtipo_documento());
            sentencia.setInt(12, usuarios.getIdusuario());
            sentencia.executeUpdate();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ActualizarusuarioDAO\n" + ex.getMessage());
        }
        return respuesta;
    }
    
    public ArrayList<usuario> consultarlistausuario(int idusuario, String nombre, String apellido, String documento, String celular, String correo,
            String direccion, String username, String clave, int tipo_documento_idtipo_documento, int ciudad_idciudad, int perfil_idperfil) throws SQLException {
        ArrayList<usuario> listadousuarios = new ArrayList<usuario>();
        usuario usuarios;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idusuario, nombre, apellido, documento, celular, correo, direccion, "
                    + "username, clave, tipo_documento_idtipo_documento, ciudad_idciudad, perfil_idperfil"
                    + " From usuario where idusuario like '%" + idusuario + "%'"
                    + " or (nombre) like ('%" + nombre + "%')"
                    + " or (apellido) like ('%" + apellido + "%')"
                    + " or (documento) like ('%" + documento + "%')"
                    + " or (celular) like ('%" + celular + "%')"
                    + " or (correo) like ('%" + correo + "%')"
                    + " or (direccion) like ('%" + direccion + "%')"
                    + " or (username) like ('%" + username + "%')"
                    + " or (clave) like ('%" + clave + "%')"
                    + " or (tipo_documento_idtipo_documento) like ('%" + tipo_documento_idtipo_documento + "%')"
                    + " or (ciudad_idciudad) like ('%" + ciudad_idciudad + "%')"
                    + " or (perfil_idperfil) like ('%" + perfil_idperfil + "%')order by idusuario;";

            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {

                usuarios = new usuario();
                usuarios.setIdusuario(rs.getInt(1));
                usuarios.setNombre(rs.getString(2));
                usuarios.setApellido(rs.getString(3));
                usuarios.setDocumento(rs.getString(4));
                usuarios.setCelular(rs.getString(5));
                usuarios.setCorreo(rs.getString(6));
                usuarios.setDireccion(rs.getString(7));
                usuarios.setUsername(rs.getString(8));
                usuarios.setClave(rs.getString(9));
                usuarios.setTipo_documento_idtipo_documento(rs.getInt(10));
                usuarios.setCiudad_idciudad(rs.getInt(11));
                usuarios.setPerfil_idperfil(rs.getInt(12));
                listadousuarios.add(usuarios);

            }
            return listadousuarios;
        } catch (Exception ex) {
            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ConsultarlistausuarioDAO\n");
        }
        return listadousuarios;
    }
    
    public String deleteusuario(usuario usuarios) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;

        try {
            String Query = "delete from usuario where nombre = ? and apellido = ? and documento = ? and celular = ? and correo = ? and direccion = ?"
                    + " and username = ? and clave = ? and Ciudad_idciudad = ? and Perfil_idperfil = ? and Tipo_documento_idtipo_documento = ? and Idusuario = ? ;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, usuarios.getNombre());
            sentencia.setString(2, usuarios.getApellido());
            sentencia.setString(3, usuarios.getDocumento());
            sentencia.setString(4, usuarios.getCelular());
            sentencia.setString(5, usuarios.getCorreo());
            sentencia.setString(6, usuarios.getDireccion());
            sentencia.setString(7, usuarios.getUsername());
            sentencia.setString(8, usuarios.getClave());
            sentencia.setInt(9, usuarios.getCiudad_idciudad());
            sentencia.setInt(10, usuarios.getPerfil_idperfil());
            sentencia.setInt(11, usuarios.getTipo_documento_idtipo_documento());
            sentencia.setInt(12, usuarios.getIdusuario());
            sentencia.execute(); 
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en deleteusuarioDAO\n" + ex.getMessage());
        }
        return respuesta;

    }
}
