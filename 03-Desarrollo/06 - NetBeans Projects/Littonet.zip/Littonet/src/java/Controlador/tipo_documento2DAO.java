/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import Modelo.tipo_documento2;

/**
 *
 * @author andre
 */
public class tipo_documento2DAO {
    
   //METODO ADICIONAR TIPOS DE DOCUMENTO 2
    
    public String adicionartipo_documento2 (tipo_documento2 OBJtipo_documento2) throws SQLException {
       
    
        String miRespuesta;
        conexion miConexion = new conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        
        try {
            
            String Query = "INSERT INTO tipo_documento2 (descripcion)" + "VALUES (?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, OBJtipo_documento2.getDescripcion());
            sentencia.execute();
            miRespuesta = "";
            
          
        } catch (Exception ex){
            
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error tipo_documento2DAO\n" + ex.getMessage());
            
        }
        return miRespuesta;
    }
    
    public tipo_documento2 consultarTipo_documento2(int idtipo_documento2) {
        tipo_documento2 miTipo_documento2 = null;

        // ESTABLECER LA CONEXION
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        // RECIBIR UN PARAMETRO DE CONSULTA idestado PARA PODER RECUPERAR LA INFORMACION 

        try {
            Statement sentencia = nuevaCon.createStatement();
            // DEFINIR EL ORDEN DE LA BÚSQUEDA 
            String querySQL = "select idtipo_documento2, descripcion from tipo_documento2 where idtipo_documento2 = '" + idtipo_documento2 + "';";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                // ASIGNAMOS LOS RESULTADOS DE LA BÚSQUEDA AL OBJETO
                miTipo_documento2 = new tipo_documento2();
                miTipo_documento2.setIdtipo_documento2(rs.getInt(1));
                miTipo_documento2.setDescripcion(rs.getString(2));

            }
            return miTipo_documento2;
        } catch (Exception ex) {
            System.out.println("Ocurrió un error en Tipo_documento2DAOConsultarEstado : " + ex.getMessage());
            return miTipo_documento2;
        }

    }

    public String actualizarTipo_documento2(tipo_documento2 OBJtipo_documento2) {

        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        // PREPARACION DE LA CONSULTA A EJECUTAR

        PreparedStatement sentencia;

        try {
            String Query = "UPDATE tipo_documento2 SET descripcion = ?"
                    + " where idtipo_documento2 = ?;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, OBJtipo_documento2.getDescripcion());
            sentencia.setInt(2, OBJtipo_documento2.getIdtipo_documento2());
            sentencia.executeUpdate();
            miRespuesta = "";

        } catch (Exception ex) {

            miRespuesta = ex.getMessage();
            System.out.println("OCURRIO UN ERROR EN tipo_documento2DAO.actualizarTipo_documento2" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    public  ArrayList <tipo_documento2> consultarListadoTipos_documento2 (int idtipo_documento2, String descripcion){
        ArrayList<tipo_documento2> misListadosTipo_documento2 = new ArrayList<tipo_documento2>();
        tipo_documento2 mistiposdocumento2;
        
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        //RECIBIR LOS CRITERIOS DE CONSULTA idTipo_documento2 PARA RECUPERAR LA INFORMACION
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            // DEFINIR ORDEN BUSQUEDAS
            String querySQL = "select idtipo_documento2, descripcion" + 
                    " from tipo_documento2 where idtipo_documento2 like '%" + idtipo_documento2 + "%'" + 
                    " or (descripcion) like ('%" + descripcion + "%')order by idtipo_documento2;";
            ResultSet rs = sentencia.executeQuery(querySQL);
            
            while (rs.next()) {
                mistiposdocumento2 = new tipo_documento2();
                mistiposdocumento2.setIdtipo_documento2(rs.getInt(1));
                mistiposdocumento2.setDescripcion(rs.getString(2));
                misListadosTipo_documento2.add(mistiposdocumento2);
            }
            return misListadosTipo_documento2;
            
        } catch (Exception ex) { 
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrió un error en tipo_documento2DAO.ConsultarListadoEstados" + ex.getMessage());
        }
        return misListadosTipo_documento2;
    }
    
    public String eliminarTipo_documento2 (tipo_documento2 OBJtipo_documento2) {
        String miRespuesta;
        conexion miConexion = new conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        
        
    try { 
        String Query = " delete from tipo_documento2 where descripcion = ? and idtipo_documento2 = ? ;";
        sentencia = nuevaCon.prepareStatement(Query);
        sentencia.setString(1, OBJtipo_documento2.getDescripcion());
        sentencia.setInt(2, OBJtipo_documento2.getIdtipo_documento2());
        sentencia.execute();
        miRespuesta = "";
        
    } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrió un error en tipo_documento2DAO.eliminarTipo_documento2" + ex.getMessage());
    }
        return miRespuesta;
    }
}
