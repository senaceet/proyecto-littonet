/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.subcategoria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
/**
 *
 * @author David
 */
public class subcategoriaDAO {
    public String adicionar_subcategoria (subcategoria subcategorias) throws SQLException{
    
            String mi_respuesta;
            conexion mi_conexion = new conexion ();
            Connection nueva_con;
            nueva_con = mi_conexion.getConn();
            
            PreparedStatement sentencia;
            try{
                String Query = "  INSERT INTO subcategoria (descripcion)" + "VALUES (?)";
                sentencia = nueva_con.prepareStatement(Query);
                sentencia.setString(1, subcategorias.getDescripcion());
                sentencia.execute();
                mi_respuesta = "";
                
            }catch (Exception ex) {
                mi_respuesta = ex.getMessage();
                    System.err.println("  Ocurrió un error en subcategoriaDAO\n " + ex.getMessage ());                                    
            }
            return mi_respuesta; 
    }
    
    public subcategoria consultar_subcategoria (int id_subcategoria){
        // MÉTODO PARA CONSULTAR UN DATO DE LA BD ╦
        subcategoria mi_subcategoria = null;
        
        //ESTABLECER LA CONEXION ╦
        String mi_respuesta;
        conexion mi_conexion = new conexion ();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        //RECIBIR UN PAÁMETRO DE CONSULTA (ID) PARA PODER RETORNAR LA INFORMACIÓN ╦
        
        try{
            Statement sentencia  = nueva_con.createStatement();
            
            //DEFINIMOS EL ORDEN DE BUSQUEDA ╦
            String querySQL = " select idsubcategoria, descripcion " +
                              " from subcategoria where idsubcategoria = '" + id_subcategoria +"';"; 
            ResultSet rs= sentencia.executeQuery(querySQL);
            
            while (rs.next()){
            //ASIGNAMOS LOS RESULTADOS DE LA BUSQUEDA AL OBJETO QUE VA A RETONRNAR LA INFOMARCIÓN ╦
            mi_subcategoria = new subcategoria();
            mi_subcategoria.setIdsubcategoria(rs.getInt(1));
            mi_subcategoria.setDescripcion(rs.getString(2));
            }  
            return mi_subcategoria;
        }
        
        catch(Exception ex){
            System.out.println(" Ha ocurrido un error en subcategoriaDAOConsulta: "+ex.getMessage());
            return mi_subcategoria;
        }
        //return mi_respuesta;
    }

    public String actualizar_subcategoria (subcategoria subcategorias){
        
        //ESTABLECER LA CONEXION ╦
        String mi_respuesta;
        conexion mi_conexion = new conexion ();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        //PREPARACION DE LA CONSULTA A EJECUTAR ╦
        PreparedStatement sentencia;
        try{
            String Query = " update subcategoria set descripcion = ? " +
                           " where idsubcategoria = ?;";
            sentencia = nueva_con.prepareStatement(Query);            
            sentencia.setString(1, subcategorias.getDescripcion());
            sentencia.setInt(2, subcategorias.getIdsubcategoria());        
            sentencia.executeUpdate();
            
            mi_respuesta= "";
        }
        catch (Exception ex) {
                mi_respuesta = ex.getMessage();
                    System.err.println("  Ocurrió un error en subcategoriaDAO.Actualizar\n " + ex.getMessage ());                                    
        }
        return mi_respuesta; 
    
    }

    public ArrayList<subcategoria> consultar_listado_subcategoria(int idsubcategoria, String descripcion){
        
        ArrayList<subcategoria> mi_listado_subcategoria = new ArrayList<subcategoria>();
        subcategoria mi_subcategoria;
    
        String mi_respuesta;
        conexion mi_conexion = new conexion();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        //RECIBIMOS CRITERIOS DE CONSULTA DE LA CLASE DAO QUE RECUPERA LA INFORMACIÓN ╦
        try {
            Statement sentencia = nueva_con.createStatement(); 
            //DEFINIR ORDEN DE BUSQUEDAS 
            String querySQL = " select idsubcategoria, descripcion " + 
                              " from subcategoria where idsubcategoria like '% " + idsubcategoria + "%'" +
                              " or (descripcion) like ('%" + descripcion + "%') ORDER BY idsubcategoria;"; 
            ResultSet rs = sentencia.executeQuery(querySQL); 
            
            while (rs.next()){
            //ASIGNAMOS LOS RESULTADOS DE LA BUSQUEDA AL OBJETO QUE VA A RETONRNAR LA INFOMARCIÓN ╦
            mi_subcategoria = new subcategoria();
            mi_subcategoria.setIdsubcategoria(rs.getInt(1));
            mi_subcategoria.setDescripcion(rs.getString(2));
            mi_listado_subcategoria.add(mi_subcategoria);
            }  
            return mi_listado_subcategoria;
        }
        catch(Exception ex){
            System.err.println(" Ha ocurrido un error en subcategoriaDAOConsultarListado: " + ex.getMessage());
            return mi_listado_subcategoria;
        } 
    }

    public String borrar_subcategoria (subcategoria subcategorias){
        
    String mi_respuesta;
        conexion mi_conexion = new conexion();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        PreparedStatement sentencia;
    try{
        String Query = " delete from subcategoria where descripcion = ? and idsubcategoria = ? ;";
        
        sentencia = nueva_con.prepareStatement(Query);
        sentencia.setString(1,subcategorias.getDescripcion());
        sentencia.setInt(2,subcategorias.getIdsubcategoria());
        
        sentencia.execute();
        
        mi_respuesta = " ";                               
    }
    catch(Exception ex){
    mi_respuesta = ex.getMessage();
            System.err.println(" Ha ocurrido un error en subcategoriaDAOBorrar: "+ex.getMessage());            
    }
    return mi_respuesta;
    }
}

