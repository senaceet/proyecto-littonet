/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.tipo_documento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author pacho
 */
public class tipo_documentoDAO {

    public String adicionardocumento(tipo_documento documento) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;
        try {
            String Query = "INSERT INTO tipo_documento (descripcion)" + "values (?);";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, documento.getDescripcion());
            sentencia.execute();
            respuesta = "";
        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error AdicionardocumentoDAO\n" + ex.getMessage());
        }

        return respuesta;
    }

    public tipo_documento consultardocumento(int idtipo_documento) throws SQLException {
        tipo_documento documentos = null;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idtipo_documento, descripcion "
                    + "from tipo_documento where idtipo_documento = '" + idtipo_documento + "';";
            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {
                documentos = new tipo_documento();
                documentos.setIdtipo_documento(rs.getInt(1));
                documentos.setDescripcion(rs.getString(2));
            }

            return documentos;

        } catch (Exception ex) {
            System.err.println("Ocurrio un error en ConsultadocumentoDAO\n" + ex.getMessage());
            return documentos;
        }
    }

    public String actualizardocumento(tipo_documento documento) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();
        PreparedStatement sentencia;

        try {
            String Query = "update tipo_documento set descripcion = ?"
                    + "where idtipo_documento = ?;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, documento.getDescripcion());
            sentencia.setInt(2, documento.getIdtipo_documento());
            sentencia.executeUpdate();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ActualizardocumentoDAO\n" + ex.getMessage());
        }
        return respuesta;
    }
    
     public ArrayList<tipo_documento> consultarlistadocumento(int idtipo_documento, String descripcion) throws SQLException {
        ArrayList<tipo_documento> listadodocumentos = new ArrayList<tipo_documento>();
        tipo_documento documentos;

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        try {
            Statement sentencia = nuevacon.createStatement();
            String querySQL = "Select idtipo_documento, descripcion"
                    + " From tipo_documento where idtipo_documento like '%" + idtipo_documento + "%'"
                    + " or (descripcion) like ('%" + descripcion + "%')order by idtipo_documento;";

            ResultSet rs = sentencia.executeQuery(querySQL);

            while (rs.next()) {

                documentos = new tipo_documento();
                documentos.setIdtipo_documento(rs.getInt(1));
                documentos.setDescripcion(rs.getString(2));
                listadodocumentos.add(documentos);

            }
            return listadodocumentos;
        } catch (Exception ex) {
            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ConsultarlistadocumentoDAO\n");
        }
        return listadodocumentos;
    }
     
     public String deletedocumento(tipo_documento documento) throws SQLException {

        String respuesta;
        conexion miconexion = new conexion();
        Connection nuevacon;
        nuevacon = miconexion.getConn();

        PreparedStatement sentencia;

        try {
            String Query = "delete from tipo_documento where descripcion = ? and idtipo_documento = ? ;";
            sentencia = nuevacon.prepareStatement(Query);
            sentencia.setString(1, documento.getDescripcion());
            sentencia.setInt(2, documento.getIdtipo_documento());
            sentencia.execute();
            respuesta = "";

        } catch (Exception ex) {

            respuesta = ex.getMessage();
            System.err.println("Ocurrio un error en deletedocumentoDAO\n" + ex.getMessage());
        }
        return respuesta;

    }
}
