/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.categoria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
/**
 *
 * @author David
 */
public class categoriaDAO {

    public String adicionar_categoria (categoria categoriass) throws SQLException{
    
            String mi_respuesta;
            conexion mi_conexion = new conexion ();
            Connection nueva_con;
            nueva_con = mi_conexion.getConn();
            
            PreparedStatement sentencia;
            try{
                
                String Query = "  INSERT INTO categoria (descripcion, subcategoria_idsubcategoria)" + "VALUES (?,?);";
                sentencia = nueva_con.prepareStatement(Query);
                sentencia.setString(1, categoriass.getDescripcion());
                sentencia.setInt(2, categoriass.getSubcategoria_idsubcategoria());
                
                sentencia.execute();
                mi_respuesta = "";
                
            }catch (Exception ex) {
                
                mi_respuesta = ex.getMessage();
                    System.err.println("  Ocurrió un error en categoria_DAO\n " + ex.getMessage ());                                    
                    
            }
            
            return mi_respuesta; 
    }

    public categoria consultar_categoria (int id_categoria){
        // MÉTODO PARA CONSULTAR UN DATO DE LA BD ╦
        categoria mi_categoria = null;
        
        //ESTABLECER LA CONEXION ╦
        String mi_respuesta;
        conexion mi_conexion = new conexion ();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        //RECIBIR UN PAÁMETRO DE CONSULTA (ID) PARA PODER RETORNAR LA INFORMACIÓN ╦
        
        try{
            Statement sentencia  = nueva_con.createStatement();
            
            //DEFINIMOS EL ORDEN DE BUSQUEDA ╦
            String querySQL = " select idcategoria, descripcion, subcategoria_idsubcategoria " +
                              " from categoria where idcategoria = '" + id_categoria +"';"; 
            ResultSet rs= sentencia.executeQuery(querySQL);
            
            while (rs.next()){
            //ASIGNAMOS LOS RESULTADOS DE LA BUSQUEDA AL OBJETO QUE VA A RETONRNAR LA INFOMARCIÓN ╦
            mi_categoria = new categoria();
            mi_categoria.setIdcategoria(rs.getInt(1));
            mi_categoria.setDescripcion(rs.getString(2));
            mi_categoria.setSubcategoria_idsubcategoria(rs.getInt(3));
            }  
            return mi_categoria;
        }
        
        catch(Exception ex){
            System.out.println(" Ha ocurrido un error en categoriaDAOConsulta: "+ex.getMessage());
            return mi_categoria;
        }
        //return mi_respuesta;
    }

    public String actualizar_categoria (categoria categorias){
        
        //ESTABLECER LA CONEXION ╦
        String mi_respuesta;
        conexion mi_conexion = new conexion ();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        //PREPARACION DE LA CONSULTA A EJECUTAR ╦
        PreparedStatement sentencia;
        try{
            String Query = " update categoria set descripcion = ?, subcategoria_idsubcategoria = ? " +
                           " where idcategoria = ?;";
            sentencia = nueva_con.prepareStatement(Query);            
            sentencia.setString(1, categorias.getDescripcion());
            sentencia.setInt(2, categorias.getSubcategoria_idsubcategoria());
            sentencia.setInt(3, categorias.getIdcategoria());        
            sentencia.executeUpdate();
            
            mi_respuesta= "";
        }
        catch (Exception ex) {
                mi_respuesta = ex.getMessage();
                    System.err.println("  Ocurrió un error en categoriaDAO.Actualizar\n " + ex.getMessage ());                                    
        }
        return mi_respuesta;     
    }

    public ArrayList<categoria> consultar_listado_categoria(int idcategoria, String descripcion, int subcategoria_idsubcategoria){
        
        ArrayList<categoria> mi_listado_categoria = new ArrayList<categoria>();
        categoria mi_categoria;
    
        String mi_respuesta;
        conexion mi_conexion = new conexion();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        //RECIBIMOS CRITERIOS DE CONSULTA DE LA CLASE DAO QUE RECUPERA LA INFORMACIÓN ╦
        try {
            Statement sentencia = nueva_con.createStatement(); 
            //DEFINIR ORDEN DE BUSQUEDAS 
            String querySQL = " select idcategoria, descripcion, subcategoria_idsubcategoria  " + 
                              " from categoria where idcategoria like '% " + idcategoria + "%'" +
                              " or (descripcion) like ('%" + descripcion + "%') or (subcategoria_idsubcategoria) like ('%" + subcategoria_idsubcategoria + "%')  ORDER BY idcategoria;"; 
            ResultSet rs = sentencia.executeQuery(querySQL); 
            
            while (rs.next()){
            //ASIGNAMOS LOS RESULTADOS DE LA BUSQUEDA AL OBJETO QUE VA A RETONRNAR LA INFOMARCIÓN ╦
            mi_categoria = new categoria();
            mi_categoria.setIdcategoria(rs.getInt(1));
            mi_categoria.setDescripcion(rs.getString(2));
            mi_categoria.setSubcategoria_idsubcategoria(rs.getInt(3));
            mi_listado_categoria.add(mi_categoria);
            }  
            return mi_listado_categoria;
        }
        catch(Exception ex){
            System.err.println(" Ha ocurrido un error en categoriaDAOConsultarListado: " + ex.getMessage());
            return mi_listado_categoria;
        } 
    }

    public String borrar_categoria (categoria categorias){
        
    String mi_respuesta;
        conexion mi_conexion = new conexion();
        Connection nueva_con;
        nueva_con = mi_conexion.getConn();
        
        PreparedStatement sentencia;
    try{
        String Query = " delete from categoria where descripcion = ? and subcategoria_idsubcategoria = ? and  idcategoria = ? ;";
        
        sentencia = nueva_con.prepareStatement(Query);
        sentencia.setString(1,categorias.getDescripcion());
        sentencia.setInt(2,categorias.getSubcategoria_idsubcategoria());
        sentencia.setInt(3,categorias.getIdcategoria());
        
        sentencia.execute();
        
        mi_respuesta = " ";                               
    }
    catch(Exception ex){
    mi_respuesta = ex.getMessage();
            System.err.println(" Ha ocurrido un error en categoriaDAOBorrar: "+ex.getMessage());            
    }
    return mi_respuesta;
    }
}
