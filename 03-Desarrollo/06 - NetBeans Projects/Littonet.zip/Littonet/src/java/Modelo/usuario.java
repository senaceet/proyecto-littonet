/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author pacho
 */
public class usuario {

    private int idusuario;
    private String nombre;
    private String apellido;
    private String documento;
    private String celular;
    private String correo;
    private String direccion;
    private String username;
    private String clave;
    private int ciudad_idciudad;
    private int perfil_idperfil;
    private int tipo_documento_idtipo_documento;

    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public int getCiudad_idciudad() {
        return ciudad_idciudad;
    }

    public void setCiudad_idciudad(int ciudad_idciudad) {
        this.ciudad_idciudad = ciudad_idciudad;
    }

    public int getPerfil_idperfil() {
        return perfil_idperfil;
    }

    public void setPerfil_idperfil(int perfil_idperfil) {
        this.perfil_idperfil = perfil_idperfil;
    }

    public int getTipo_documento_idtipo_documento() {
        return tipo_documento_idtipo_documento;
    }

    public void setTipo_documento_idtipo_documento(int tipo_documento_idtipo_documento) {
        this.tipo_documento_idtipo_documento = tipo_documento_idtipo_documento;
    }

    
}
