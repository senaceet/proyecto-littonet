/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author David
 */
public class producto {
    
    private int idproducto;
    private int precio;
    private String imagen;
    private String caracteristicas;
    private int unidad_medida_idunidad_medida;
    private int categoria_idcategoria;

    public int getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(int idproducto) {
        this.idproducto = idproducto;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getCaracteristicas() {
        return caracteristicas;
    }

    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }

    public int getUnidad_medida_idunidad_medida() {
        return unidad_medida_idunidad_medida;
    }

    public void setUnidad_medida_idunidad_medida(int unidad_medida_idunidad_medida) {
        this.unidad_medida_idunidad_medida = unidad_medida_idunidad_medida;
    }

    public int getCategoria_idcategoria() {
        return categoria_idcategoria;
    }

    public void setCategoria_idcategoria(int categoria_idcategoria) {
        this.categoria_idcategoria = categoria_idcategoria;
    }

}