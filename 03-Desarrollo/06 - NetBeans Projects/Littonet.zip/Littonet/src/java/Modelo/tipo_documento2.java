/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author andre
 */
public class tipo_documento2 {
    
    private int idtipo_documento2;
    private String descripcion;

    public int getIdtipo_documento2() {
        return idtipo_documento2;
    }

    public void setIdtipo_documento2(int idtipo_documento2) {
        this.idtipo_documento2 = idtipo_documento2;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }    
    
}
