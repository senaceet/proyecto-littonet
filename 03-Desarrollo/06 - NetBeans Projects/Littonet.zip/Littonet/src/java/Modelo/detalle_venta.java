/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author andre
 */
public class detalle_venta {

    private int iddetalle_venta;
    private int cantidad;

    private int estado_idestado;
    private int tipo_envio_idtipo_envio;
    private int medio_pago_idmedio_pago;
    private int producto_idproducto;
    private int especificacion_idespecificacion;

    public int getIddetalle_venta() {
        return iddetalle_venta;
    }

    public void setIddetalle_venta(int iddetalle_venta) {
        this.iddetalle_venta = iddetalle_venta;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getEstado_idestado() {
        return estado_idestado;
    }

    public void setEstado_idestado(int estado_idestado) {
        this.estado_idestado = estado_idestado;
    }

    public int getTipo_envio_idtipo_envio() {
        return tipo_envio_idtipo_envio;
    }

    public void setTipo_envio_idtipo_envio(int tipo_envio_idtipo_envio) {
        this.tipo_envio_idtipo_envio = tipo_envio_idtipo_envio;
    }

    public int getMedio_pago_idmedio_pago() {
        return medio_pago_idmedio_pago;
    }

    public void setMedio_pago_idmedio_pago(int medio_pago_idmedio_pago) {
        this.medio_pago_idmedio_pago = medio_pago_idmedio_pago;
    }

    public int getProducto_idproducto() {
        return producto_idproducto;
    }

    public void setProducto_idproducto(int producto_idproducto) {
        this.producto_idproducto = producto_idproducto;
    }

    public int getEspecificacion_idespecificacion() {
        return especificacion_idespecificacion;
    }

    public void setEspecificacion_idespecificacion(int especificacion_idespecificacion) {
        this.especificacion_idespecificacion = especificacion_idespecificacion;
    }

}
