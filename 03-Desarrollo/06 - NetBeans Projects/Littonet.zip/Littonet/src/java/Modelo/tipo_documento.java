/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author pacho
 */
public class tipo_documento {
    
    private int idtipo_documento;
    private String descripcion;
    
    public int getIdtipo_documento() {
        return idtipo_documento;
    }

    public void setIdtipo_documento(int idtipo_documento) {
        this.idtipo_documento = idtipo_documento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
   
}
