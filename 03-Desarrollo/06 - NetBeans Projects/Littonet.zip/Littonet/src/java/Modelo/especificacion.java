/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author andre
 */
public class especificacion {
    
    private int idespecificacion;
    private String descripcion;
    
    private int iddetalle_venta;
    
    public int getIdespecificacion() {
        return idespecificacion;
    }

    public void setIdespecificacion(int idespecificacion) {
        this.idespecificacion = idespecificacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
       public int getIddetalle_venta() {
        return iddetalle_venta;
    }

    public void setIddetalle_venta(int iddetalle_venta) {
        this.iddetalle_venta = iddetalle_venta;
    }

}
