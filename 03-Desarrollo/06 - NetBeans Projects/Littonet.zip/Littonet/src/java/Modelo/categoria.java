/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author David
 */
public class categoria {
    
    private int idcategoria;
    private String descripcion;
    private int subcategoria_idsubcategoria;

    public int getIdcategoria() {
        return idcategoria;
    }

    public void setIdcategoria(int idcategoria) {
        this.idcategoria = idcategoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getSubcategoria_idsubcategoria() {
        return subcategoria_idsubcategoria;
    }

    public void setSubcategoria_idsubcategoria(int subcategoria_idsubcategoria) {
        this.subcategoria_idsubcategoria = subcategoria_idsubcategoria;
    }
 
}
