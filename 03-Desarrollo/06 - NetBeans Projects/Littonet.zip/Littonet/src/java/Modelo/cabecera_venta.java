/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;


/**
 *
 * @author andre
 */
public class cabecera_venta {
    
    private int idcabecera_venta;
    private String fecha;
    private int referencia;

    private int usuario_idusuario;
    private int detalle_venta_iddetalle_venta;
    private int tipo_documento2_idtipo_documento2;
    
    public int getIdcabecera_venta() {
        return idcabecera_venta;
    }

    public void setIdcabecera_venta(int idcabecera_venta) {
        this.idcabecera_venta = idcabecera_venta;
    }

    public String getFecha() {
        return fecha;
    }
        
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getReferencia() {
        return referencia;
    }

    public void setReferencia(int referencia) {
        this.referencia = referencia;
    }
    
    public int getUsuario_idusuario() {
        return usuario_idusuario;
    }

    public void setUsuario_idusuario(int usuario_idusuario) {
        this.usuario_idusuario = usuario_idusuario;
    }

    public int getDetalle_venta_iddetalle_venta() {
        return detalle_venta_iddetalle_venta;
    }

    public void setDetalle_venta_iddetalle_venta(int detalle_venta_iddetalle_venta) {
        this.detalle_venta_iddetalle_venta = detalle_venta_iddetalle_venta;
    }

    public int getTipo_documento2_idtipo_documento2() {
        return tipo_documento2_idtipo_documento2;
    }

    public void setTipo_documento2_idtipo_documento2(int tipo_documento2_idtipo_documento2) {
        this.tipo_documento2_idtipo_documento2 = tipo_documento2_idtipo_documento2;
    }
    
}
