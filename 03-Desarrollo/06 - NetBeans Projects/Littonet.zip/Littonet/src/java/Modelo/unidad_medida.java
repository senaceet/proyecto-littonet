/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author David
 */
public class unidad_medida {
    
    private int idunidad_medida;
    private String descripcion;

    public int getIdunidad_medida() {
        return idunidad_medida;
    }

    public void setIdunidad_medida(int idunidad_medida) {
        this.idunidad_medida = idunidad_medida;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
}
